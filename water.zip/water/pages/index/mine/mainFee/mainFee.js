// pages/index/mine/mainFee/mainFee.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '维护费统计', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    consume_record_status: true,
    consume_record: [],
    total_nomoney: '',
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取维护费统计
    that.getMainFee()
  },

  // 获取维护费统计
  getMainFee: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    server.getData('', '/count/countDefendMoney', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.datas.length != 0) {
          for (var i = 0; i < res.data.datas.length; i++) {
            res.data.datas[i].moneyDeal = Number(res.data.datas[i].money).toFixed(2)
            res.data.datas[i].nomoneyDeal = Number(res.data.datas[i].nomoney).toFixed(2)
          }
          that.setData({
            consume_record: res.data.datas,
            consume_record_status: true
          })
        } else {
          that.setData({
            consume_record: [],
            consume_record_status: false
          })
        }
        var count = Number(res.data.count).toFixed(2)
        that.setData({
          total_nomoney: count
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})