// pages/index/mine/shareProfit/shareProfit.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '分润统计', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    user_infor: '',
    share_tab: ['合伙人', '物业公司'],
    current_index: 0,
    partner_current_page: 1,
    partner_total_page: '',
    partner_list_status: true,
    partner_list: [],
    property_current_page: 1,
    property_total_page: '',
    property_list_status: true,
    property_list: [],
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.user_infor = wx.getStorageSync('user')
    // 获取分润统计数据
    that.getShareProfit('5', 1, '15')
  },

  // 获取分润统计数据
  getShareProfit: function (roleId, page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      roleId: roleId,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/count/profitCount', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          if (that.data.current_index == 0) {
            for (var i = 0; i < res.data.length; i++) {
              res.data[i].paymoneyDeal = Number(res.data[i].paymoney) / 100
            }
            var partner_list = that.data.partner_list.concat(res.data);
            that.setData({
              partner_list: partner_list,
              partner_list_status: true
            })
            var count = res.count;
            var partner_total_page = count / 15 < 1 ? 0 : count / 15;
            if (count % 15 == 0) {
              that.data.partner_total_page = partner_total_page;
            } else {
              that.data.partner_total_page = parseInt(partner_total_page) + 1;
            }
          } else if (that.data.current_index == 1) {
            for (var i = 0; i < res.data.length; i++) {
              res.data[i].paymoneyDeal = Number(res.data[i].paymoney) / 100
              res.data[i].moneyDeal = Number(res.data[i].money) * 1000 / 100000
            }
            var property_list = that.data.property_list.concat(res.data);
            that.setData({
              property_list: property_list,
              property_list_status: true
            })
            var count = res.count;
            var property_total_page = count / 15 < 1 ? 0 : count / 15;
            if (count % 15 == 0) {
              that.data.property_total_page = property_total_page;
            } else {
              that.data.property_total_page = parseInt(property_total_page) + 1;
            }
          }
        } else {
          if (that.data.current_index == 0) {
            that.setData({
              partner_list: [],
              partner_list_status: false
            })
          } else if (that.data.current_index == 1) {
            that.setData({
              property_list: [],
              property_list_status: false
            })
          }
        }
      }
    })
  },

  // 点击分润tab 
  shareTab: function (e) {
    var that = this;
    that.setData({
      current_index: e.currentTarget.dataset.index
    })
    if (e.currentTarget.dataset.index == 0) {
      that.data.partner_current_page = 1;
      that.data.partner_total_page = '';
      that.data.partner_list = [];
      // 获取分润统计数据
      that.getShareProfit('5', 1, '15')
    } else if (e.currentTarget.dataset.index == 1) {
      that.data.property_current_page = 1;
      that.data.property_total_page = '';
      that.data.property_list = [];
      // 获取分润统计数据
      that.getShareProfit('4', 1, '15')
    }
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    if (that.data.current_index == 0) {
      var partner_current_page = that.data.partner_current_page + 1;
      that.setData({
        partner_current_page: partner_current_page
      })
      if (partner_current_page <= that.data.partner_total_page) {
        // 获取分润统计数据
        that.getShareProfit('5', partner_current_page, '15')
      }
    } else if (that.data.current_index == 1) {
      var property_current_page = that.data.property_current_page + 1;
      that.setData({
        property_current_page: property_current_page
      })
      if (property_current_page <= that.data.property_total_page) {
        // 获取分润统计数据
        that.getShareProfit('4', property_current_page, '15')
      }
    }
  },

  // 点击结算按钮
  settleBtn: function (e) {
    var that = this;
    if (that.data.current_index == 0) {
      wx.showModal({
        title: '收益结算',
        content: '结算金额：' + that.data.partner_list[e.currentTarget.dataset.index].money + '元，确定结算吗？',
        confirmText: '结算',
        success(res) {
          if (res.confirm) {
            that.setData({
              loading_layer_status: 'show'
            })
            var account = Number(that.data.partner_list[e.currentTarget.dataset.index].money)
            account = account * 10000 * 100 / 10000
            var sendData = {
              account: account,
              acc_time: that.data.partner_list[e.currentTarget.dataset.index].accTime,
              userId: that.data.partner_list[e.currentTarget.dataset.index].parId,
              accUserId: that.data.user_infor.id,
            }
            server.postFData(sendData, '/userAccounts/updateuserAccount', function (res) {
              // console.log(res)
              that.setData({
                loading_layer_status: 'hidden'
              })
              if (res.code == 200) {
                wx.showToast({
                  title: '结算成功！',
                  icon: 'none'
                })
                that.data.partner_list[e.currentTarget.dataset.index].paymoneyDeal = Number(that.data.partner_list[e.currentTarget.dataset.index].money)
                that.data.partner_list[e.currentTarget.dataset.index].money = '0'
                that.setData({
                  partner_list: that.data.partner_list
                })
              } else {
                wx.showToast({
                  title: res.message,
                  icon: 'none'
                })
              }
            })
          }
        }
      })
    } else if (that.data.current_index == 1) {
      wx.showModal({
        title: '收益结算',
        content: '结算金额：' + Number(that.data.property_list[e.currentTarget.dataset.index].money / 100).toFixed(1) + '元，确定结算吗？',
        confirmText: '结算',
        success(res) {
          if (res.confirm) {
            that.setData({
              loading_layer_status: 'show'
            })
            var account = Number(that.data.property_list[e.currentTarget.dataset.index].money)
            var sendData = {
              account: account,
              acc_time: that.data.property_list[e.currentTarget.dataset.index].accTime,
              userId: that.data.property_list[e.currentTarget.dataset.index].proId,
              accUserId: that.data.user_infor.id,
            }
            server.postFData(sendData, '/userAccounts/updateuserAccount', function (res) {
              // console.log(res)
              that.setData({
                loading_layer_status: 'hidden'
              })
              if (res.code == 200) {
                wx.showToast({
                  title: '结算成功！',
                  icon: 'none'
                })
                that.data.property_list[e.currentTarget.dataset.index].paymoneyDeal = Number(that.data.property_list[e.currentTarget.dataset.index].money) / 100
                that.data.property_list[e.currentTarget.dataset.index].money = '0'
                that.data.property_list[e.currentTarget.dataset.index].moneyDeal = '0'
                that.setData({
                  property_list: that.data.property_list
                })
              } else {
                wx.showToast({
                  title: res.message,
                  icon: 'none'
                })
              }
            })
          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})