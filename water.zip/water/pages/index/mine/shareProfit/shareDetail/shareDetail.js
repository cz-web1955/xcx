// pages/index/mine/shareProfit/shareDetail/shareDetail.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '详情', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    partner_id: '',
    current_page: 1,
    total_page: '',
    detail_list_status: true,
    detail_list: [],
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.partner_id = options.id
    // 获取合伙人收益详情
    that.getShareDetail(1, '10')
  },

  // 获取合伙人收益详情
  getShareDetail: function (page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      userId: that.data.partner_id,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/count/profitCountByUserId', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          var detail_list = that.data.detail_list.concat(res.data);
          that.setData({
            detail_list: detail_list,
            detail_list_status: true
          })
          var count = res.count;
          var total_page = count / 10 < 1 ? 0 : count / 10;
          if (count % 10 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            detail_list: [],
            detail_list_status: false
          })
        }
      }
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    var current_page = that.data.current_page + 1;
    that.setData({
      current_page: current_page
    })
    if (current_page <= that.data.total_page) {
      // 获取合伙人收益详情
      that.getShareDetail(current_page, '10')
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})