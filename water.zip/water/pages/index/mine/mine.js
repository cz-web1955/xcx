// pages/index/mine/mine.js
var app = getApp();
// 引入request.js
var server = require('../../../utils/request.js')
// 引入util.js
var util = require('../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '我的', backStatus: false },
    top_height: '',
    window_height: app.globalData.windowHeight,
    user_infor: '',
    mine_list: [],
    bottom_nav: [],
    agent_status: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  // 点击修改按钮
  updateInfor: function () {
    var that = this;
    wx.navigateTo({
      url: '/pages/index/mine/personInfor/personInfor',
    })
  },

  // 点击退出登录
  logoutBtn: function () {
    wx.showModal({
      title: '提示',
      content: '确定退出吗？',
      success(res) {
        if (res.confirm) {
          wx.clearStorageSync('token')
          wx.clearStorageSync('user')
          wx.reLaunch({
            url: '/pages/login/login',
          })
        }
      }
    })
  },

  // 点击底部导航
  skipPage: function (e) {
    var that = this;
    if (e.currentTarget.dataset.url != '') {
      wx.reLaunch({
        url: e.currentTarget.dataset.url,
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.setData({
      user_infor: wx.getStorageSync('user')
    })
    that.data.agent_status = that.data.user_infor.agent_status
    if (that.data.agent_status == 1) {
      // 代理商
      var mine_list = [
        { title: '修改密码', pathUrl: '/pages/index/mine/updatePass/updatePass' },
        { title: '合伙人', pathUrl: '/pages/index/mine/partner/partner' },
        { title: '物业公司', pathUrl: '/pages/index/mine/property/property' },
        { title: '区域信息', pathUrl: '/pages/index/mine/areaInfor/areaInfor' },
        { title: '分润统计', pathUrl: '/pages/index/mine/shareProfit/shareProfit' },
        { title: '维护费统计', pathUrl: '/pages/index/mine/mainFee/mainFee' },
        { title: '投币统计', pathUrl: '/pages/index/mine/insertCoin/insertCoin' },
        { title: '修改余额统计', pathUrl: '/pages/index/mine/updateBStatic/updateBStatic' },
        { title: '提现记录', pathUrl: '/pages/index/mine/withdraw/withdraw' },
        { title: '用户充值套餐', pathUrl: '/pages/index/mine/userMeal/userMeal' },
        { title: '卡套餐', pathUrl: '/pages/index/mine/cardMeal/cardMeal' },
        { title: '设置水价模板', pathUrl: '/pages/index/mine/waterTem/waterTem' },
      ]
      var bottom_nav = [
        { title: '首页', iconUrl: 'https://api.010ozner.com/image/1.png', selected: false, pathUrl: '/pages/index/home/home' },
        { title: '统计', iconUrl: 'https://api.010ozner.com/image/2.png', selected: false, pathUrl: '/pages/index/statis/statis' },
        { title: '我的', iconUrl: 'https://api.010ozner.com/image/33.png', selected: true, pathUrl: '' }
      ]
      that.setData({
        mine_list: mine_list,
        bottom_nav: bottom_nav
      })
    } else if (that.data.agent_status == 2) {
      // 促销员
      var mine_list = [
        { title: '修改密码', pathUrl: '/pages/index/mine/updatePass/updatePass' },
        // { title: '申请额度', pathUrl: '/pages/index/mine/applyLimit/applyLimit' },
        { title: '分润统计', pathUrl: '/pages/index/mine/sharePSale/sharePSale' },
      ]
      var bottom_nav = [
        { title: '首页', iconUrl: 'https://api.010ozner.com/image/1.png', selected: false, pathUrl: '/pages/index/home/home' },
        { title: '我的', iconUrl: 'https://api.010ozner.com/image/33.png', selected: true, pathUrl: '' }
      ]
      that.setData({
        mine_list: mine_list,
        bottom_nav: bottom_nav
      })
    } else if (that.data.agent_status == 3) {
      // 合伙人、物业公司
      var mine_list = [
        { title: '修改密码', pathUrl: '/pages/index/mine/updatePass/updatePass' },
      ]
      var bottom_nav = [
        { title: '首页', iconUrl: 'https://api.010ozner.com/image/1.png', selected: false, pathUrl: '/pages/index/home/home' },
        { title: '我的', iconUrl: 'https://api.010ozner.com/image/33.png', selected: true, pathUrl: '' }
      ]
      that.setData({
        mine_list: mine_list,
        bottom_nav: bottom_nav
      })
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})