// pages/index/mine/partner/partner.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '合伙人', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    partner_search: '',
    current_page: 1,
    total_page: '',
    partner_list_status: true,
    partner_list: [],
    judge_page_status: false,
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取合伙人列表
    that.getPartner(that.data.partner_search, 1, '10')
  },

  // 获取合伙人列表
  getPartner: function (partner, page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      roleId: '5',
      search: partner,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/users/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          var partner_list = that.data.partner_list.concat(res.data);
          that.setData({
            partner_list: partner_list,
            partner_list_status: true
          })
          var count = res.count;
          var total_page = count / 10 < 1 ? 0 : count / 10;
          if (count % 10 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            partner_list: [],
            partner_list_status: false
          })
        }
      }
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    var current_page = that.data.current_page + 1;
    that.setData({
      current_page: current_page
    })
    if (current_page <= that.data.total_page) {
      // 获取合伙人列表
      that.getPartner(that.data.partner_search, current_page, '10')
    }
  },

  // 监听合伙人/手机号input
  watchPartnerInput: function (e) {
    var that = this;
    that.data.partner_search = e.detail.value
  },

  // 点击确定按钮
  confirmSearch: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.partner_list = [];
    // 获取合伙人列表
    that.getPartner(that.data.partner_search, 1, '10')
  },

  // 点击禁用或启用按钮
  useForbidBtn: function (e) {
    var that = this;
    var status_text;
    if (e.currentTarget.dataset.status == '0') {
      status_text = '确定禁用吗？'
    } else if (e.currentTarget.dataset.status == '1') {
      status_text = '确定启用吗？'
    }
    wx.showModal({
      title: '提示',
      content: status_text,
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            id: e.currentTarget.dataset.id,
            status: e.currentTarget.dataset.status
          }
          server.postData(sendData, '/users/updateStatus', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '操作成功！',
                icon: 'none'
              })
              that.data.partner_list[e.currentTarget.dataset.index].status = Number(e.currentTarget.dataset.status)
              that.setData({
                partner_list: that.data.partner_list
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_status) {
      that.data.current_page = 1;
      that.data.total_page = '';
      that.data.partner_list = [];
      // 获取合伙人列表
      that.getPartner(that.data.partner_search, 1, '10')
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_status = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})