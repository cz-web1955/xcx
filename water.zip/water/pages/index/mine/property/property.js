// pages/index/mine/property/property.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '物业公司', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    current_page: 1,
    total_page: '',
    property_list_status: true,
    property_list: [],
    loading_layer_status: 'hidden',
    property_search: '',
    judge_page_status: false,
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取物业公司列表
    that.getProperty(that.data.property_search, 1, '10')
  },

  // 获取物业公司列表
  getProperty: function (property, page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      roleId: '4',
      search: property,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/users/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].proportionDeal = res.data[i].proportion / 100
          }
          var property_list = that.data.property_list.concat(res.data);
          that.setData({
            property_list: property_list,
            property_list_status: true
          })
          var count = res.count;
          var total_page = count / 10 < 1 ? 0 : count / 10;
          if (count % 10 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            property_list: [],
            property_list_status: false
          })
        }
      }
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    var current_page = that.data.current_page + 1;
    that.setData({
      current_page: current_page
    })
    if (current_page <= that.data.total_page) {
      // 获取物业公司列表
      that.getProperty(that.data.property_search, current_page, '10')
    }
  },

  // 监听物业名称/手机号input
  watchPropertyInput: function (e) {
    var that = this;
    that.data.property_search = e.detail.value
  },

  // 点击确定按钮
  confirmSearch: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.property_list = [];
    // 获取物业公司列表
    that.getProperty(that.data.property_search, 1, '10')
  },

  // 点击禁用或启用按钮
  useForbidBtn: function (e) {
    var that = this;
    var status_text;
    if (e.currentTarget.dataset.status == '0') {
      status_text = '确定禁用吗？'
    } else if (e.currentTarget.dataset.status == '1') {
      status_text = '确定启用吗？'
    }
    wx.showModal({
      title: '提示',
      content: status_text,
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            id: e.currentTarget.dataset.id,
            status: e.currentTarget.dataset.status
          }
          server.postData(sendData, '/users/updateStatus', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '操作成功！',
                icon: 'none'
              })
              that.data.property_list[e.currentTarget.dataset.index].status = Number(e.currentTarget.dataset.status)
              that.setData({
                property_list: that.data.property_list
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_status) {
      that.data.current_page = 1;
      that.data.total_page = '';
      that.data.property_list = [];
      // 获取物业公司列表
      that.getProperty(that.data.property_search, 1, '10')
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_status = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})