// pages/index/mine/property/propertyAdd/propertyAdd.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '添加物业公司', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    share_cate: '0',
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  // 监听分润类型
  watchRadioChange: function (e) {
    var that = this;
    that.setData({
      share_cate: e.detail.value
    })
  },

  // 点击保存按钮
  addSubmit: function (e) {
    var that = this;
    var phone_reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
    if (e.detail.value.property == '') {
      wx.showToast({
        title: '请输入物业公司！',
        icon: 'none'
      })
    } else if (e.detail.value.phone == '') {
      wx.showToast({
        title: '请输入手机号！',
        icon: 'none'
      })
    } else if (!phone_reg.test(e.detail.value.phone)) {
      wx.showToast({
        title: '请输入正确的手机号！',
        icon: 'none'
      })
    } else {
      if (that.data.share_cate == '0') {
        if (e.detail.value.siteFee == '') {
          wx.showToast({
            title: '请输入场地费！',
            icon: 'none'
          })
        } else if (Number(e.detail.value.siteFee) <= 0) {
          wx.showToast({
            title: '场地费必须大于0！',
            icon: 'none'
          })
        } else {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            roleId: '4',
            nickname: e.detail.value.property,
            username: e.detail.value.phone,
            phone: e.detail.value.phone,
            password: '123456',
            rent: Number(e.detail.value.siteFee) * 100,
          }
          server.postFData(sendData, '/users/updateUser', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '添加物业公司成功！',
                icon: 'none'
              })
              setTimeout(function () {
                wx.navigateBack({
                  delta: 1,
                })
              }, 1500)
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      } else if (that.data.share_cate == '1') {
        if (e.detail.value.percent == '') {
          wx.showToast({
            title: '请输入提成比例！',
            icon: 'none'
          })
        } else if (Number(e.detail.value.percent) < 0 || Number(e.detail.value.percent) > 100) {
          wx.showToast({
            title: '提成比例只能是0-100之间的数！',
            icon: 'none'
          })
        } else {
          if (e.detail.value.percent.split('.').length > 1) {
            if (e.detail.value.percent.split('.')[1].length == 1) {
              that.setData({
                loading_layer_status: 'show'
              })
              var sendData = {
                roleId: '4',
                nickname: e.detail.value.property,
                username: e.detail.value.phone,
                phone: e.detail.value.phone,
                password: '123456',
                proportion: (Number(e.detail.value.percent) * 100).toFixed(2).split('.')[0],
              }
              // 添加物业公司
              that.addProperty(sendData)
            } else {
              wx.showToast({
                title: '提成比例最多只能输入一位小数！',
                icon: 'none'
              })
            }
          } else {
            that.setData({
              loading_layer_status: 'show'
            })
            var sendData = {
              roleId: '4',
              nickname: e.detail.value.property,
              username: e.detail.value.phone,
              phone: e.detail.value.phone,
              password: '123456',
              proportion: (Number(e.detail.value.percent) * 100).toFixed(2).split('.')[0],
            }
            // 添加物业公司
            that.addProperty(sendData)
          }
        }
      }
    }
  },

  // 添加物业公司
  addProperty: function (sendData) {
    var that = this;
    server.postFData(sendData, '/users/updateUser', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        wx.showToast({
          title: '添加物业公司成功！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.navigateBack({
            delta: 1,
          })
        }, 1500)
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})