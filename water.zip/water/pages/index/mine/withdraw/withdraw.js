// pages/index/mine/mainFee/mainFee.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '提现记录', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    consume_record_status: true,
    consume_record: [],
    total_nomoney: '',
    loading_layer_status: 'hidden',
    page:1,
    count:""
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取提现记录列表
    that.getMainFee()
    that.getMainFee1()
  },

  // 获取提现记录列表
  getMainFee: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    server.getData({
      page:that.data.page,
      limit:30
    }, '/users/withdrawal', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].amount = Number(res.data[i].amount).toFixed(2)
          }
          var consume_record = that.data.consume_record.concat(res.data);
          that.setData({
            consume_record: consume_record,
            consume_record_status: true
          })
        } else {
          that.setData({
            consume_record: [],
            consume_record_status: false
          })
        }
        var count = res.count
        that.setData({
          count: count
        })
      }
    })
  },
// 获取待提现金额
  getMainFee1: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    server.postData('', '/paylogs/statistical', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        
        that.setData({
          total_nomoney: res.data.toFixed(2)
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
   // 页面滚动到底部时
   toLower: function () {
    var that = this;
    if(that.data.page*30>=that.data.count){
      return false
    }
    var current_page = that.data.page + 1;
    that.setData({
      page: current_page
    })
    // 获取提现记录列表
    that.getMainFee()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})