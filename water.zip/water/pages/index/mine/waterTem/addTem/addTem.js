// pages/index/mine/waterTem/addTem/addTem.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '添加模板', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    water_cate_show: [],
    water_cate: [],
    water_index: 0,
    fee_list: [],
    add_num: -1,
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取水类型列表
    that.getWaterCate()
  },

  // 获取水类型列表
  getWaterCate: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    server.getData('', '/dicts?type=water', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      for (var j = 0; j < res.length; j++) {
        that.data.water_cate_show.push(res[j].val)
      }
      for (var i = 0; i < 4; i++) {
        that.data.fee_list.push({ id: i, flag: false, cateArr: res, arr: that.data.water_cate_show, arrIndex: 0 })
      }
      that.setData({
        water_cate_show: that.data.water_cate_show,
        water_cate: res,
        fee_list: that.data.fee_list
      })
    })
  },

  // 监听类型1
  bindFirstChange: function (e) {
    var that = this;
    that.setData({
      water_index: e.detail.value
    })
  },

  // 点击添加计费模式按钮
  addModel: function () {
    var that = this;
    for (var i = 0; i < that.data.fee_list.length; i++) {
      if (that.data.fee_list[i].flag == false) {
        that.data.fee_list[i].flag = true
        that.setData({
          fee_list: that.data.fee_list
        })
        break;
      }
    }
    if (that.data.add_num < 4) {
      that.data.add_num = that.data.add_num + 1
    }
    if (that.data.add_num >= 4) {
      wx.showToast({
        title: '最多只能添加5个计费模式！',
        icon: 'none'
      })
    }
  },

  // 点击删除按钮
  delModel: function (e) {
    var that = this;
    if (that.data.add_num >= 3) {
      that.data.add_num = 3
    }
    that.data.add_num = that.data.add_num - 1
    that.data.fee_list[e.currentTarget.dataset.index].flag = false
    that.setData({
      fee_list: that.data.fee_list
    })
  },

  // 监听类型
  bindPickerChange: function (e) {
    var that = this;
    that.data.fee_list[e.currentTarget.dataset.id].arrIndex = Number(e.detail.value)
    that.setData({
      fee_list: that.data.fee_list
    })
  },

  // 点击确定按钮
  addSubmit: function (e) {
    var that = this;
    var selected_cate = [];
    var selected_index = [];
    var price_arr = [];
    var vol_arr = [];
    if (e.detail.value.temName == '') {
      wx.showToast({
        title: '请输入模板名称！',
        icon: 'none'
      })
    } else if (e.detail.value.priceadd == '') {
      wx.showToast({
        title: '请输入计费模式对应的元！',
        icon: 'none'
      })
    } else if (e.detail.value.voladd == '') {
      wx.showToast({
        title: '请输入计费模式对应的升！',
        icon: 'none'
      })
    } else {
      for (var i = 0; i < that.data.fee_list.length; i++) {
        if (that.data.fee_list[i].flag) {
          selected_cate.push(that.data.fee_list[i].cateArr[that.data.fee_list[i].arrIndex].k)
        }
      }
      if (selected_cate.length != 0) {
        for (var i in e.detail.value) {
          if (e.detail.value.hasOwnProperty(i)) {
            if (e.detail.value[i] != '') {
              if (i.split('_')[1]) {
                selected_index.push(Number(i.split('_')[1]))
                price_arr.push((Number(e.detail.value[i]) * 100).toFixed(0))
              }
              if (i.split('/')[1]) {
                vol_arr.push((Number(e.detail.value[i]) * 100).toFixed(0))
              }
            }
          }
        }
        if (selected_index.length == 0) {
          wx.showToast({
            title: '请输入计费模式对应的元或升！',
            icon: 'none'
          })
        } else {
          if (price_arr.length < selected_cate.length) {
            wx.showToast({
              title: '请输入计费模式对应的元！',
              icon: 'none'
            })
          } else if (vol_arr.length < selected_cate.length) {
            wx.showToast({
              title: '请输入计费模式对应的升！',
              icon: 'none'
            })
          } else {
            that.setData({
              loading_layer_status: 'show'
            })
            selected_cate.unshift(that.data.water_cate[that.data.water_index].k)
            price_arr.unshift((Number(e.detail.value.priceadd) * 100).toFixed(0))
            vol_arr.unshift((Number(e.detail.value.voladd) * 100).toFixed(0))
            var sendData = {
              modelname: e.detail.value.temName,
              price: price_arr.toString(),
              vol: vol_arr.toString(),
              waterTypes: selected_cate.toString(),
              remand: e.detail.value.temDescri,
              nums: price_arr.length,
            }
            // 添加模板API
            that.addTemApi(sendData)
          }
        }
      } else {
        that.setData({
          loading_layer_status: 'show'
        })
        var sendData = {
          modelname: e.detail.value.temName,
          price: (Number(e.detail.value.priceadd) * 100).toFixed(0),
          vol: (Number(e.detail.value.voladd) * 100).toFixed(0),
          waterTypes: that.data.water_cate[that.data.water_index].k,
          remand: e.detail.value.temDescri,
          nums: 1,
        }
        // 添加模板API
        that.addTemApi(sendData)
      }
    }
  },

  // 添加模板API
  addTemApi: function (sendData) {
    var that = this;
    server.postFData(sendData, '/waterPrice/updateWaterPrice', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        wx.showToast({
          title: '添加模板成功！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.navigateBack({
            delta: 1
          })
        }, 1500)
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})