// pages/index/mine/waterTem/waterTem.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '水价模板', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    user_infor: '',
    current_page: 1,
    total_page: '',
    tem_list_status: true,
    tem_list: [],
    judge_page_show: false,
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.user_infor = wx.getStorageSync('user')
    // 获取水价模板列表
    that.getWaterTem(1, '15')
  },

  // 获取水价模板列表
  getWaterTem: function (page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      modelname: '',
      agentId: that.data.user_infor.id,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/waterPrice/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          var tem_list = that.data.tem_list.concat(res.data);
          that.setData({
            tem_list: tem_list,
            tem_list_status: true
          })
          var count = res.count;
          var total_page = count / 15 < 1 ? 0 : count / 15;
          if (count % 15 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            tem_list: [],
            tem_list_status: false
          })
        }
      }
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    var current_page = that.data.current_page + 1;
    that.setData({
      current_page: current_page
    })
    if (current_page <= that.data.total_page) {
      // 获取水价模板列表
      that.getWaterTem(current_page, '15')
    }
  },

  // 点击删除按钮
  delTem: function (e) {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定删除该模板吗？',
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            id: that.data.tem_list[e.currentTarget.dataset.index].id
          }
          server.postFData(sendData, '/waterPrice/del', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '删除成功！',
                icon: 'none'
              })
              that.data.tem_list.splice(e.currentTarget.dataset.index, 1)
              that.setData({
                tem_list: that.data.tem_list
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_show) {
      that.data.current_page = 1;
      that.data.total_page = '';
      that.data.tem_list = [];
      // 获取水价模板列表
      that.getWaterTem(1, '15')
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_show = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})