// pages/index/mine/lossCard/lossCard.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '挂失卡', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    card_search: '',
    current_page: 1,
    total_page: '',
    loss_card_status: true,
    loss_card: [],
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取挂失卡列表
    that.getLossCard(1, '10')
  },

  // 获取挂失卡列表
  getLossCard: function (page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      status: '1',
      page: page,
      limit: limit,
    }
    server.postData(sendData, '/waterCards/findList', function (res) {
      console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].countMoneyDeal = (res.data[i].countMoney / 100).toFixed(2)
          }
          var loss_card = that.data.loss_card.concat(res.data);
          that.setData({
            loss_card: loss_card,
            loss_card_status: true
          })
          var count = res.count;
          var total_page = count / 10 < 1 ? 0 : count / 10;
          if (count % 10 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            loss_card: [],
            loss_card_status: false
          })
        }
      }
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    var current_page = that.data.current_page + 1;
    that.setData({
      current_page: current_page
    })
    if (current_page <= that.data.total_page) {
      // 获取挂失卡列表
      that.getLossCard(current_page, '10')
    }
  },

  // 监听卡号/手机号input
  watchCardInput: function (e) {
    var that = this;
    that.data.card_search = e.detail.value
  },

  // 点击确定按钮
  confirmSearch: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.loss_card = [];
    // 获取挂失卡列表
    that.getLossCard(1, '10')
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})