// pages/index/mine/cardMeal/cardMeal.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '卡套餐', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    user_infor: '',
    current_page: 1,
    total_page: '',
    meal_list_status: true,
    meal_list: [],
    judge_page_show: false,
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.user_infor = wx.getStorageSync('user')
    // 获取卡套餐列表
    that.getCardMeal(1, '15')
  },

  // 获取卡套餐列表
  getCardMeal: function (page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      name: '',
      userId: that.data.user_infor.id,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/cardMeals/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].moneyDeal = (res.data[i].money / 100).toFixed(2)
            res.data[i].giveMoneyDeal = (res.data[i].giveMoney / 100).toFixed(2)
          }
          var meal_list = that.data.meal_list.concat(res.data);
          that.setData({
            meal_list: meal_list,
            meal_list_status: true
          })
          var count = res.count;
          var total_page = count / 15 < 1 ? 0 : count / 15;
          if (count % 15 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            meal_list: [],
            meal_list_status: false
          })
        }
      }
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    var current_page = that.data.current_page + 1;
    that.setData({
      current_page: current_page
    })
    if (current_page <= that.data.total_page) {
      // 获取卡套餐列表
      that.getCardMeal(current_page, '15')
    }
  },

  // 点击删除按钮
  delMeal: function (e) {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定删除该套餐吗？',
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            id: that.data.meal_list[e.currentTarget.dataset.index].id
          }
          server.postFData(sendData, '/cardMeals/del', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '删除成功！',
                icon: 'none'
              })
              that.data.meal_list.splice(e.currentTarget.dataset.index, 1)
              that.setData({
                meal_list: that.data.meal_list
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_show) {
      that.data.current_page = 1;
      that.data.total_page = '';
      that.data.meal_list = [];
      // 获取卡套餐列表
      that.getCardMeal(1, '15')
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_show = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})