// pages/index/mine/cardMeal/editMeal/editMeal.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '编辑卡套餐', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    user_infor: '',
    meal_id: '',
    meal_infor: '',
    current_index: 0,
    card_cate: ['普通卡', '套餐卡'],
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.meal_id = options.id
    that.data.user_infor = wx.getStorageSync('user')
    // 获取套餐信息
    that.getMealInfor()
  },

  // 获取套餐信息
  getMealInfor: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      name: '',
      id: that.data.meal_id,
      userId: that.data.user_infor.id,
      page: 1,
      limit: '1'
    }
    server.postData(sendData, '/cardMeals/findList', function (res) {
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        res.data[0].moneyDeal = Number(res.data[0].money) / 100
        res.data[0].giveMoneyDeal = Number(res.data[0].giveMoney) / 100
        if (Number(res.data[0].daysum) < 1) {
          that.data.current_index = 0
        } else {
          that.data.current_index = 1
        }
        that.setData({
          meal_infor: res.data[0],
          current_index: res.data[0].type-1
        })
      }
    })
  },

  // 点击卡类型tab
  cateTab: function (e) {
    var that = this;
    that.setData({
      current_index: e.currentTarget.dataset.index
    })
  },

  // 点击确定按钮
  editSubmit: function (e) {
    var that = this;
    var num_reg = /^([1-9]\d*(\.\d*[1-9])?)|(0\.\d*[1-9])$/
    if (e.detail.value.mealName == '') {
      wx.showToast({
        title: '请输入套餐名称！',
        icon: 'none'
      })
    } else if (e.detail.value.chargeMoney == '') {
      wx.showToast({
        title: '请输入充值金额！',
        icon: 'none'
      })
    } else if (!num_reg.test(e.detail.value.chargeMoney)) {
      wx.showToast({
        title: '充值金额必须为大于0的数！',
        icon: 'none'
      })
    } else {
      if (e.detail.value.giveMoney != '') {
        if (Number(e.detail.value.giveMoney) >= 0) {
          if (that.data.current_index == 1) {
            
              that.setData({
                loading_layer_status: 'show'
              })
              var sendData = {
                id: that.data.meal_id,
                name: e.detail.value.mealName,
                money: Number(e.detail.value.chargeMoney) * 100,
                giveMoney: Number(e.detail.value.giveMoney) * 100,
                daysum: e.detail.value.daysum,
                type: that.data.current_index+1
              }
              // 卡套餐
              that.cardMealApi(sendData)
            
          } else if (that.data.current_index == 0) {
            that.setData({
              loading_layer_status: 'show'
            })
            var sendData = {
              id: that.data.meal_id,
              name: e.detail.value.mealName,
              money: Number(e.detail.value.chargeMoney) * 100,
              giveMoney: Number(e.detail.value.giveMoney) * 100,
              daysum: 0,
              type: that.data.current_index+1
            }
            // 卡套餐
            that.cardMealApi(sendData)
          }
        } else {
          wx.showToast({
            title: '赠送金额必须不小于0！',
            icon: 'none'
          })
        }
      } else {
        if (that.data.current_index == 1) {
          
            that.setData({
              loading_layer_status: 'show'
            })
            var sendData = {
              id: that.data.meal_id,
              name: e.detail.value.mealName,
              money: Number(e.detail.value.chargeMoney) * 100,
              giveMoney: 0,
              daysum: e.detail.value.daysum,
              type: that.data.current_index+1
            }
            // 卡套餐
            that.cardMealApi(sendData)
          
        } else if (that.data.current_index == 0) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            id: that.data.meal_id,
            name: e.detail.value.mealName,
            money: Number(e.detail.value.chargeMoney) * 100,
            giveMoney: 0,
            daysum: 0,
            type: that.data.current_index+1
          }
          // 卡套餐
          that.cardMealApi(sendData)
        }
      }
    }
  },

  // 卡套餐
  cardMealApi: function (sendData) {
    var that = this;
    server.postFData(sendData, '/cardMeals/updatecardMeal', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        wx.showToast({
          title: '编辑卡套餐成功！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.navigateBack({
            delta: 1
          })
        }, 1500)
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})