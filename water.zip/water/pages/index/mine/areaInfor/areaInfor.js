// pages/index/mine/areaInfor/areaInfor.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '区域信息', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    area_list_status: true,
    area_list: [],
    judge_page_show: false,
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取区域列表
    that.getArea()
  },

  // 获取区域列表
  getArea: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      name: '',
      page: 1,
      limit: '10000',
    }
    server.postData(sendData, '/areas/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          that.setData({
            area_list: res.data,
            area_list_status: true
          })
        } else {
          that.setData({
            area_list: [],
            area_list_status: false
          })
        }
      }
    })
  },

  // 点击删除按钮
  delArea: function (e) {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定删除该区域吗？',
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          server.getData('', '/areas/del/' + e.currentTarget.dataset.id, function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '删除该区域成功',
                icon: 'none'
              })
              // 获取区域列表
              that.getArea()
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_show) {
      // 获取区域列表
      that.getArea()
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_show = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})