// pages/index/home/fans/fans.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '用户管理', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    fans_search: '',
    current_page: 1,
    total_page: '',
    fans_list_status: true,
    fans_list: [],
    loading_layer_status: 'hidden',
    judge_page_status: false
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取用户列表
    that.getFansList(that.data.fans_search, 1, '15')
  },

  // 获取用户列表
  getFansList: function (search, page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      search: search,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/wechat/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].amountDeal = (res.data[i].amount / 100).toFixed(2)
            res.data[i].packageAmount = (res.data[i].packageAmount / 100).toFixed(2)
            res.data[i].endTime = res.data[i].endTime==null?'0.00':res.data[i].endTime.split(" ")[0]
            if (i == 0) {
              res.data[i].status = true
            } else {
              res.data[i].status = false
            }
          }
          var fans_list = that.data.fans_list.concat(res.data);
          that.setData({
            fans_list: fans_list,
            fans_list_status: true
          })
          var count = res.count;
          var total_page = count / 15 < 1 ? 0 : count / 15;
          if (count % 15 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            fans_list: [],
            fans_list_status: false
          })
        }
      }
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    var current_page = that.data.current_page + 1;
    that.setData({
      current_page: current_page
    })
    if (current_page <= that.data.total_page) {
      // 获取用户列表
      that.getFansList(that.data.fans_search, current_page, '15')
    }
  },

  // 点击箭头
  changeStatus: function (e) {
    var that = this;
    that.data.fans_list[e.currentTarget.dataset.index].status = !that.data.fans_list[e.currentTarget.dataset.index].status
    that.setData({
      fans_list: that.data.fans_list
    })
  },

  // 监听昵称/手机号input
  watchFansInput: function (e) {
    var that = this;
    that.data.fans_search = e.detail.value
  },

  // 点击确定按钮
  confirmSearch: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.fans_list = [];
    // 获取用户列表
    that.getFansList(that.data.fans_search, 1, '15')
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_status) {
      that.data.current_page = 1;
      that.data.total_page = '';
      that.data.fans_list = [];
      // 获取用户列表
      that.getFansList(that.data.fans_search, 1, '15')
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_status = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})