// pages/index/home/fans/walletRecharge/walletRecharge.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: {
      statusBarHeight: app.globalData.statusBarHeight,
      title: '钱包充值',
      backStatus: true
    },
    top_height: '',
    window_height: app.globalData.windowHeight,
    money_list: [],
    money_list2: [],
    current_index: 0,
    charge_money: '',
    give_money: '',
    daysum: "",
    wx_id: '',
    endTimes:"",
    loading_layer_status: 'hidden',
    card_cate: ['普通钱包', '时效钱包'],
    type: 1
  },
  // 点击卡类型tab
  cateTab: function (e) {
    var that = this;
    that.setData({
      type: e.currentTarget.dataset.index + 1
    })
    if (e.currentTarget.dataset.index == 0) {
      that.setData({
        charge_money: that.data.money_list[0].money,
        give_money: that.data.money_list[0].giveMoney,
        daysum: that.data.money_list[0].daysum,
        current_index:0
      })
    } else {
      that.setData({
        charge_money: that.data.money_list2[0].money,
        give_money: that.data.money_list2[0].giveMoney,
        daysum: that.data.money_list2[0].daysum,
        current_index:0
      })
    }

  },
  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.wx_id = options.id
    that.data.endTimes = options.endTime=='0.00'?'':options.endTime
    // that.data.endTimes = ''
    // 获取充值金额列表
    that.getMoneyList()
  },

  // 获取充值金额列表
  getMoneyList: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      page: 1,
      limit: '10000'
    }
    server.postData(sendData, '/userMeals/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        var moneyarr = [],
          moneyarr2 = []
        if (res.data.length != 0) {
          res.data.forEach(item => {
            if (item.type == 1) {
              moneyarr.push(item)
            } else {
              moneyarr2.push(item)
            }
          })
          if(moneyarr.length){
            that.setData({
              charge_money: moneyarr[0].money,
              give_money: moneyarr[0].giveMoney,
              daysum: moneyarr[0].daysum,
            })
          }
          
        } else {
          that.setData({
            charge_money: '',
            give_money: '',
          })
        }
        moneyarr.push({
          id: -1,
          name: '手工输入',
          daysum: -5
        })
        that.setData({
          money_list: moneyarr,
          money_list2: moneyarr2,
        })
      }
    })
  },

  // 点击金额tab
  moneyTab: function (e) {
    var that = this;
    if( that.data.type==1){
      if (e.currentTarget.dataset.index != that.data.money_list.length - 1) {
        that.setData({
          charge_money: that.data.money_list[e.currentTarget.dataset.index].money,
          give_money: that.data.money_list[e.currentTarget.dataset.index].giveMoney,
          daysum: that.data.money_list[e.currentTarget.dataset.index].daysum
        })
      }                                                                                
    }else{
      that.setData({
        charge_money: that.data.money_list2[e.currentTarget.dataset.index].money,
        give_money: that.data.money_list2[e.currentTarget.dataset.index].giveMoney,
        daysum: that.data.money_list2[e.currentTarget.dataset.index].daysum
      })
    }
    
    that.setData({
      current_index: e.currentTarget.dataset.index
    })
  },

  // 点击充值按钮
  rechargeSubmit: function (e) {
    var that = this;
    if (that.data.type == 1) {
      if (that.data.current_index != that.data.money_list.length - 1) {
        // 套餐充值
        that.setData({
          loading_layer_status: 'show'
        })
        var sendData = {
          wxUserId: that.data.wx_id,
          countMoney: that.data.money_list[that.data.current_index].money,
          giveMoney: that.data.money_list[that.data.current_index].giveMoney,
          type:1
        }
        server.postFData(sendData, '/waterCards/pay', function (res) {
          // console.log(res)
          that.setData({
            loading_layer_status: 'hidden'
          })
          if (res.code == 200) {
            wx.showToast({
              title: '钱包充值成功！',
              icon: 'none'
            })
            setTimeout(function () {
              wx.navigateBack({
                delta: 1
              })
            }, 1500)
          } else {
            wx.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
      } else {
        // 其他充值
        if (e.detail.value.rechargeMoney == '') {
          wx.showToast({
            title: '请输入充值金额！',
            icon: 'none'
          })
        } else if (Number(e.detail.value.rechargeMoney) <= 0) {
          wx.showToast({
            title: '充值金额必须大于0！',
            icon: 'none'
          })
        } else if (Number(e.detail.value.rechargeMoney) > 5000) {
          wx.showToast({
            title: '充值金额最多只能充值5000！',
            icon: 'none'
          })
        } else if (Number(e.detail.value.giveMoney) <0) {
          wx.showToast({
            title: '赠送金额不能小于0！',
            icon: 'none'
          })
        } else if (Number(e.detail.value.giveMoney) > 5000) {
          wx.showToast({
            title: '赠送金额最多只能充值5000！',
            icon: 'none'
          })
        } else {
          that.setData({
            loading_layer_status: 'show'
          })
          var countMoney = (Number(e.detail.value.rechargeMoney) * 100).toFixed(0)
          var giveMoney = (Number(e.detail.value.giveMoney) * 100).toFixed(0)
          var sendData = {
            wxUserId: that.data.wx_id,
            countMoney: countMoney,
            giveMoney: giveMoney,
            type:1
          }
          // console.log(sendData)
          server.postFData(sendData, '/waterCards/pay', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '钱包充值成功！',
                icon: 'none'
              })
              setTimeout(function () {
                wx.navigateBack({
                  delta: 1
                })
              }, 1500)
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    }else{
      // 套餐充值
      that.setData({
        loading_layer_status: 'show'
      })
      var now_date,day_nums,end_time
      now_date = new Date()
      day_nums = Number(that.data.money_list2[that.data.current_index].daysum) * 24 * 60 * 60 * 1000
      // console.log(that.data.endTimes=='',new Date().getTime())
      if(that.data.endTimes==''||new Date(that.data.endTimes).getTime()<new Date().getTime()){
        end_time = now_date.setTime(now_date.getTime() + day_nums)
        end_time = util.formatYTime(new Date(end_time))
      }else{
        end_time = now_date.setTime(new Date(that.data.endTimes).getTime() + day_nums)
        end_time = util.formatYTime(new Date(end_time))
      }
      var sendData = {
        wxUserId: that.data.wx_id,
        countMoney: that.data.money_list2[that.data.current_index].money,
        giveMoney: that.data.money_list2[that.data.current_index].giveMoney,
        endTime:end_time,
        type:2
      }
      server.postFData(sendData, '/waterCards/pay', function (res) {
        // console.log(res)
        that.setData({
          loading_layer_status: 'hidden'
        })
        if (res.code == 200) {
          wx.showToast({
            title: '钱包充值成功！',
            icon: 'none'
          })
          setTimeout(function () {
            wx.navigateBack({
              delta: 1
            })
          }, 1500)
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})