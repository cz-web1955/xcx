// pages/index/home/fans/bindCard/bindCard.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '绑卡', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    user_id: '',
    balance_money: '',
    card_num: '',
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.user_id = options.id
  },

  // 输入框失去焦点时
  blurInput: function (e) {
    var that = this;
    if (e.detail.value != '') {
      that.setData({
        loading_layer_status: 'show'
      })
      server.getData('', '/waterCards/findByCardId/' + e.detail.value, function (res) {
        // console.log(res)
        that.setData({
          loading_layer_status: 'hidden'
        })
        if (res.code == 200) {
          if (res.data != null) {
            if (res.data.status == '0') {
              var balance_money = res.data.countMoney / 100
              that.setData({
                balance_money: balance_money
              })
            } else {
              wx.showToast({
                title: '该卡无效或已挂失或未激活！',
                icon: 'none'
              })
              that.setData({
                balance_money: ''
              })
            }
          } else {
            wx.showToast({
              title: '该卡不存在！',
              icon: 'none'
            })
            that.setData({
              balance_money: ''
            })
          }
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    }
  },

  // 点击扫码按钮
  scanCode: function (e) {
    var that = this;
    wx.scanCode({
      success: function (res) {
        that.setData({
          card_num: res.result
        })
      }
    })
  },

  // 点击绑定按钮
  bindSubmit: function (e) {
    var that = this;
    if (e.detail.value.cardNum == '') {
      wx.showToast({
        title: '请输入卡号！',
        icon: 'none'
      })
    } else {
      that.setData({
        loading_layer_status: 'show'
      })
      var sendData = {
        cardId: e.detail.value.cardNum,
        id: that.data.user_id
      }
      server.postData(sendData, '/wxUsers/addCard', function (res) {
        // console.log(res)
        that.setData({
          loading_layer_status: 'hidden'
        })
        if (res.code == 200) {
          wx.showToast({
            title: '绑定水卡成功！',
            icon: 'none'
          })
          setTimeout(function () {
            wx.navigateBack({
              delta: 1
            })
          }, 1500)
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})