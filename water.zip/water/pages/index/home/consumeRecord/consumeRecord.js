// pages/index/home/consumeRecord/consumeRecord.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')
var dateTimePicker = require('../../../../utils/dateTimePicker.js');
var animation = wx.createAnimation({
  duration: 500,
  timingFunction: 'ease-in-out',
});

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '消费记录', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    aside_width: app.globalData.windowWidth * 0.6,
    card_num: '',
    wx_id: '',
    device_id: '',
    start_time: '',
    end_time: '',
    current_page: 1,
    total_page: '',
    consume_record_status: true,
    consume_record: [],
    startYear: 2010,
    endYear: 2030,
    dateTime1: '',
    dateTimeArray1: '',
    dateTime2: '',
    dateTimeArray2: '',
    loading_layer_status: 'hidden',
    area_search: '',
    consume_search: '',
    filter_layer_flag: 'hidden',
    area_list: [],
    area_index: -1,
    consume_cate: [],
    consume_index: -1,
    filter_item_status: [true, true],
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      wx_id: options.wxid
    })
    var obj1 = dateTimePicker.dateTimePicker(that.data.startYear, that.data.endYear);
    var obj2 = dateTimePicker.dateTimePicker(that.data.startYear, that.data.endYear);
    if (obj1.dateTime[2] >= 0 && obj1.dateTime[2] < 2) {
      obj1.dateTime[1] = obj1.dateTime[1] - 1
      obj1.dateTime[2] = obj1.dateTimeArray[2].length - 2
    } else {
      obj1.dateTime[2] = obj1.dateTime[2] - 2
    }
    obj1.dateTime[3] = 0
    obj1.dateTime[4] = 0
    obj1.dateTime[5] = 0
    that.data.start_time = obj1.dateTimeArray[0][obj1.dateTime[0]] + '-' + obj1.dateTimeArray[1][obj1.dateTime[1]] + '-' + obj1.dateTimeArray[2][obj1.dateTime[2]] + ' ' + obj1.dateTimeArray[3][obj1.dateTime[3]] + ':' + obj1.dateTimeArray[4][obj1.dateTime[4]] + ':' + obj1.dateTimeArray[5][obj1.dateTime[5]]
    that.data.end_time = util.formatYTime(new Date())
    // console.log(that.data.start_time)
    // console.log(that.data.end_time)
    that.setData({
      dateTime1: obj1.dateTime,
      dateTimeArray1: obj1.dateTimeArray,
      dateTime2: obj2.dateTime,
      dateTimeArray2: obj2.dateTimeArray,
    });
    // 获取消费记录列表
    that.getConsumeRecord(that.data.card_num, that.data.wx_id, that.data.device_id, that.data.start_time, that.data.end_time, that.data.area_search, that.data.consume_search, 1, '20')
  },

  // 获取消费记录列表
  getConsumeRecord: function (cardNum, wxId, deviceId, startTime, endTime, areaId, consumerType, page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      wxUserId: wxId,
      cardId: cardNum,
      deviceId: deviceId,
      sTime: startTime,
      eTime: endTime,
      areaId: areaId,
      consumerType: consumerType,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/consumerLogs/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].status = false;
            res.data[i].accountDeal = (res.data[i].account / 100).toFixed(2);
            res.data[i].createTimeDeal = res.data[i].createTime.split(' ')[0] + '\n' + res.data[i].createTime.split(' ')[1]
          }
          var consume_record = that.data.consume_record.concat(res.data);
          that.setData({
            consume_record: consume_record,
            consume_record_status: true
          })
          var count = res.count;
          var total_page = count / 20 < 1 ? 0 : count / 20;
          if (count % 20 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            consume_record: [],
            consume_record_status: false
          })
        }
      }
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    var current_page = that.data.current_page + 1;
    that.setData({
      current_page: current_page
    })
    if (current_page <= that.data.total_page) {
      // 获取消费记录列表
      that.getConsumeRecord(that.data.card_num, that.data.wx_id, that.data.device_id, that.data.start_time, that.data.end_time, that.data.area_search, that.data.consume_search, current_page, '20')
    }
  },

  // 监听卡号input
  watchConsumeInput: function (e) {
    var that = this;
    that.data.card_num = e.detail.value
  },

  // 监听设备编号input
  watchEquipInput: function (e) {
    var that = this;
    that.data.device_id = e.detail.value
  },

  // 点击确定按钮
  confirmSearch: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.consume_record = [];
    if ((new Date(that.data.end_time.replace(/-/g, "/"))).getTime() >= (new Date(that.data.start_time.replace(/-/g, "/"))).getTime()) {
      // 获取消费记录列表
      that.getConsumeRecord(that.data.card_num, that.data.wx_id, that.data.device_id, that.data.start_time, that.data.end_time, that.data.area_search, that.data.consume_search, 1, '20')
    } else {
      wx.showToast({
        title: '结束时间必须大于开始时间！',
        icon: 'none'
      })
    }
  },

  // 监听开始日期变化
  changeDateTime1(e) {
    var that = this;
    that.data.start_time = that.data.dateTimeArray1[0][e.detail.value[0]] + '-' + that.data.dateTimeArray1[1][e.detail.value[1]] + '-' + that.data.dateTimeArray1[2][e.detail.value[2]] + ' ' + that.data.dateTimeArray1[3][e.detail.value[3]] + ':' + that.data.dateTimeArray1[4][e.detail.value[4]] + ':' + that.data.dateTimeArray1[5][e.detail.value[5]]
    that.setData({
      dateTime1: e.detail.value,
    });
  },

  // 监听结束日期变化
  changeDateTime2(e) {
    var that = this;
    that.data.end_time = that.data.dateTimeArray2[0][e.detail.value[0]] + '-' + that.data.dateTimeArray2[1][e.detail.value[1]] + '-' + that.data.dateTimeArray2[2][e.detail.value[2]] + ' ' + that.data.dateTimeArray2[3][e.detail.value[3]] + ':' + that.data.dateTimeArray2[4][e.detail.value[4]] + ':' + that.data.dateTimeArray2[5][e.detail.value[5]]
    that.setData({
      dateTime2: e.detail.value,
    });
  },

  // 点击筛选按钮
  filterBoxPopup: function () {
    var that = this;
    // 获取区域列表
    that.getArea()
    // 获取消费类型
    that.getConsumeCate()
    animation.translateX(-that.data.aside_width).step();
    that.setData({
      filter_animation: animation.export(),
      filter_layer_flag: 'show'
    });
  },

  // 获取区域列表
  getArea: function () {
    var that = this;
    var sendData = {
      page: 1,
      limit: '10000'
    }
    server.postData(sendData, '/areas/findList', function (res) {
      // console.log(res)
      if (res.code == 200) {
        that.setData({
          area_list: res.data
        })
      }
    })
  },

  // 获取消费类型
  getConsumeCate: function () {
    var that = this;
    var sendData = {
      type: 'consumerType'
    }
    server.postData(sendData, '/dicts/getDict', function (res) {
      // console.log(res)
      if (res.code == 200) {
        that.setData({
          consume_cate: res.data
        })
      }
    })
  },

  // 点击遮罩层
  filterBoxDismiss: function () {
    var that = this;
    animation.translateX(that.data.aside_width).step();
    that.setData({
      filter_animation: animation.export(),
      filter_layer_flag: 'hidden'
    });
  },

  // 点击筛选箭头
  filterStatus: function (e) {
    var that = this;
    that.data.filter_item_status[Number(e.currentTarget.dataset.index)] = !that.data.filter_item_status[Number(e.currentTarget.dataset.index)]
    that.setData({
      filter_item_status: that.data.filter_item_status
    })
  },

  // 点击区域tab
  areaTab: function (e) {
    var that = this;
    that.setData({
      area_index: e.currentTarget.dataset.index
    })
  },

  // 点击消费类型tab
  consumeTab: function (e) {
    var that = this;
    that.setData({
      consume_index: e.currentTarget.dataset.index
    })
  },

  // 点击筛选按钮
  fifterBtn: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.consume_record = [];
    if (that.data.area_index != -1) {
      that.data.area_search = that.data.area_list[that.data.area_index].id
    } else {
      that.data.area_search = ''
    }
    if (that.data.consume_index != -1) {
      that.data.consume_search = that.data.consume_cate[that.data.consume_index].k
    } else {
      that.data.consume_search = ''
    }
    // 获取消费记录列表
    that.getConsumeRecord(that.data.card_num, that.data.wx_id, that.data.device_id, that.data.start_time, that.data.end_time, that.data.area_search, that.data.consume_search, 1, '20')
    that.filterBoxDismiss()
  },

  // 点击重置按钮
  resetBtn: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.consume_record = [];
    that.data.area_search = '';
    that.data.consume_search = '';
    that.setData({
      area_index: -1,
      consume_index: -1,
    })
    // 获取消费记录列表
    that.getConsumeRecord(that.data.card_num, that.data.wx_id, that.data.device_id, that.data.start_time, that.data.end_time, that.data.area_search, that.data.consume_search, 1, '20')
    that.filterBoxDismiss()
  },

  // 点击详情按钮
  lookDetail: function (e) {
    var that = this;
    that.data.consume_record[e.currentTarget.dataset.index].status = !that.data.consume_record[e.currentTarget.dataset.index].status
    that.setData({
      consume_record: that.data.consume_record
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})