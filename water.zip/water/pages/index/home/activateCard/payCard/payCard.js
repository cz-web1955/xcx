// pages/index/home/activateCard/payCard/payCard.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '代客开卡', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    area_ids: '',
    card_num: '',
    phone_num: '',
    user_name: '',
    money_list1: [],
    money_list2: [],
    money_index: 0,
    loading_layer_status: 'hidden',
    charge_money: '',
    agent_status:"",
    give_money: '',
    card_cate: ['普通卡', '套餐卡'],
    type:1,
    daysum:""
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },
  // 点击卡类型tab
  cateTab: function (e) {
    var that = this;
    that.setData({
      type: e.currentTarget.dataset.index+1
    })
    that.setData({
      money_index: 0
    })
    if (e.currentTarget.dataset.index == 0) {
      that.setData({
        charge_money: Number(that.data.money_list1[0].money) / 100,
        give_money: Number(that.data.money_list1[0].giveMoney) / 100,
        daysum:that.data.money_list1[0].daysum
      })
    } else if (e.currentTarget.dataset.index == 1 && that.data.money_list2.length!=0){
      that.setData({
        charge_money: Number(that.data.money_list2[0].money) / 100,
        give_money: Number(that.data.money_list2[0].giveMoney) / 100,
        daysum:that.data.money_list2[0].daysum
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.area_ids = options.ids
    that.setData({
      agent_status: wx.getStorageSync('user').agent_status
    })
    // 获取卡类型列表
    that.getCardCate()
  },

  // 获取卡类型列表
  getCardCate: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      page: 1,
      limit: '10000'
    }
    server.postData(sendData, '/cardMeals/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          that.setData({
            charge_money: Number(res.data[0].money) / 100,
            give_money: Number(res.data[0].giveMoney) / 100,
            daysum:res.data[0].daysum
          })
        } else {
          that.setData({
            charge_money: '',
            give_money: '',
          })
        }
        let moneyarr = [], moneyarr2 = []
        res.data.forEach(item=>{
          if(item.type==1){
            moneyarr.push(item)
          }else{
            moneyarr2.push(item)
          }
        })
        // that.data.money_list = res.data;
        moneyarr.push({ id: -1, name: '手工输入' })
        that.setData({
          money_list1: moneyarr,
          money_list2: moneyarr2,
        })
      }
    })
  },

  // 点击扫码按钮
  scanCode: function (e) {
    var that = this;
    wx.scanCode({
      success: function (res) {
        that.setData({
          card_num: res.result
        })
      }
    })
  },

  // 点击金额列表
  moneyTab: function (e) {
    var that = this;
    if (that.data.type==1&&e.currentTarget.dataset.index != that.data.money_list1.length - 1) {
      that.setData({
        charge_money: Number(that.data.money_list1[e.currentTarget.dataset.index].money) / 100,
        give_money: Number(that.data.money_list1[e.currentTarget.dataset.index].giveMoney) / 100,
        daysum:that.data.money_list1[e.currentTarget.dataset.index].daysum
      })
    }
    if (that.data.type == 2) {
      that.setData({
        charge_money: Number(that.data.money_list2[e.currentTarget.dataset.index].money) / 100,
        give_money: Number(that.data.money_list2[e.currentTarget.dataset.index].giveMoney) / 100,
        daysum:that.data.money_list2[e.currentTarget.dataset.index].daysum
      })
    }
    that.setData({
      money_index: e.currentTarget.dataset.index
    })
  },

  // 点击开卡按钮
  paySubmit: function (e) {
    var that = this;
    var phone_reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/
    if (e.detail.value.cardNum == '') {
      wx.showToast({
        title: '请输入卡号！',
        icon: 'none'
      })
    } else {
      //判断普通卡是否手工输入
      if (that.data.type == 1 && that.data.money_index == that.data.money_list1.length - 1 ){
        if (e.detail.value.charging == '') {
          wx.showToast({
            title: '请输入充值金额！',
            icon: 'none'
          })
          return false
        }
        if (Number(e.detail.value.giving) < 0) {
          wx.showToast({
            title: '充值金额不能小于等于0！',
            icon: 'none'
          })
          return false
        }
        if (Number(e.detail.value.charging) > 5000) {
          wx.showToast({
            title: '充值金额最多只能充值5000！',
            icon: 'none'
          })
          return false
        }
        if (Number(e.detail.value.giving) < 0) {
          wx.showToast({
            title: '赠送金额不能小于0！',
            icon: 'none'
          })
          return false
        }
        if (Number(e.detail.value.giving) > 5000) {
          wx.showToast({
            title: '赠送金额最多只能充值5000！',
            icon: 'none'
          })
          return false
        }
          var giving = e.detail.value.giving == '' ? 0 : Number(e.detail.value.giving) * 100
          var sendData = {
            deviceId: '',
            areaIds: that.data.area_ids,
            cardId: e.detail.value.cardNum,
            countMoney: Number(e.detail.value.charging) * 100,
            giveMoney: giving,
            phone: e.detail.value.phone,
            uname: e.detail.value.uname,
            cardType: 0,
          }
        
      }
      //判断是普通卡套餐
      if (that.data.type == 1 && that.data.money_index!= that.data.money_list1.length - 1) {
        sendData = {
          deviceId: '',
          areaIds: that.data.area_ids,
          cardId: e.detail.value.cardNum,
          countMoney: Number(that.data.money_list1[that.data.money_index].money),
          giveMoney: Number(that.data.money_list1[that.data.money_index].giveMoney),
          phone: e.detail.value.phone,
          uname: e.detail.value.uname,
          cardType: 0,
        }
      }
      //判断是套餐卡套餐
      if (that.data.type == 2) {
        var now_date = new Date()
        var day_nums = Number(that.data.money_list2[that.data.money_index].daysum) * 24 * 60 * 60 * 1000
        var end_time = now_date.setTime(now_date.getTime() + day_nums)
        end_time = util.formatYTime(new Date(end_time))
        var sendData = {
          deviceId: '',
          areaIds: that.data.area_ids,
          cardId: e.detail.value.cardNum,
          countMoney: Number(that.data.money_list2[that.data.money_index].money),
          giveMoney: Number(that.data.money_list2[that.data.money_index].giveMoney),
          endTime: end_time,
          phone: e.detail.value.phone,
          uname: e.detail.value.uname,
          cardType: 1,
        }
      }
      if (that.data.agent_status == 2&&sendData.countMoney>wx.getStorageSync('normDeal')) {
        wx.showToast({
          title: '剩余开卡额度不足！',
          icon:"none"
        })
        return false
      }
      wx.showModal({
        title: '开卡',
        content: '确认开此卡吗？',
        success (res) {
          if (res.confirm) { // 开卡
            that.openCardApi(sendData)
          } else if (res.cancel) {
            // console.log('用户点击取消')
          }
        }
      })
     
      // 
      
    }
  },

  // 开卡
  openCardApi: function (sendData) {
    var that = this;
    server.postFData(sendData, '/waterCards/openCard', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        wx.showModal({
          title: '开卡成功',
          content: '水卡开卡成功，请选择其他操作。',
          confirmText: '继续开卡',
          success(res) {
            if (res.confirm) {
              if (that.data.money_list.length > 1) {
                that.setData({
                  card_num: '',
                  phone_num: '',
                  user_name: '',
                  charge_money: Number(that.data.money_list[0].money) / 100,
                  give_money: Number(that.data.money_list[0].giveMoney) / 100,
                  money_index: 0
                })
              } else {
                that.setData({
                  card_num: '',
                  phone_num: '',
                  user_name: '',
                  money_index: 0
                })
              }
            } else if (res.cancel) {
              wx.navigateBack({
                delta: 2
              })
            }
          }
        })
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})