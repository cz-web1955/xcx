// pages/index/home/openCardRS/openCardRS.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '开卡记录', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    card_tab: ['卡管理', '挂失卡'],
    current_index: 0,
    card_search: '',
    card_current_page: 1,
    card_total_page: '',
    card_list_status: true,
    card_list: [],
    loss_current_page: 1,
    loss_total_page: '',
    loss_list_status: true,
    loss_list: [],
    loading_layer_status: 'hidden',
    judge_page_status: false
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取开卡记录
    that.getOpenCard('', '0', 1, '10')
  },

  // 获取开卡记录
  getOpenCard: function (cardId, status, page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      cardId: cardId,
      status: status,
      page: page,
      limit: limit,
    }
    server.postData(sendData, '/waterCards/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          if (that.data.current_index == 0) {
            // 卡管理
            for (var i = 0; i < res.data.length; i++) {
              res.data[i].countMoneyDeal = (res.data[i].countMoney / 100).toFixed(2)
            }
            var card_list = that.data.card_list.concat(res.data);
            that.setData({
              card_list: card_list,
              card_list_status: true,
            })
            var count = res.count;
            var card_total_page = count / 10 < 1 ? 0 : count / 10;
            if (count % 10 == 0) {
              that.data.card_total_page = card_total_page;
            } else {
              that.data.card_total_page = parseInt(card_total_page) + 1;
            }
          } else if (that.data.current_index == 1) {
            // 挂失卡
            for (var i = 0; i < res.data.length; i++) {
              res.data[i].countMoneyDeal = (res.data[i].countMoney / 100).toFixed(2)
            }
            var loss_list = that.data.loss_list.concat(res.data);
            that.setData({
              loss_list: loss_list,
              loss_list_status: true,
            })
            var count = res.count;
            var loss_total_page = count / 10 < 1 ? 0 : count / 10;
            if (count % 10 == 0) {
              that.data.loss_total_page = loss_total_page;
            } else {
              that.data.loss_total_page = parseInt(loss_total_page) + 1;
            }
          }
        } else {
          if (that.data.current_index == 0) {
            // 卡管理
            that.setData({
              card_list: [],
              card_list_status: false
            })
          } else if (that.data.current_index == 1) {
            // 挂失卡
            that.setData({
              loss_list: [],
              loss_list_status: false
            })
          }
        }
      }
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    if (that.data.current_index == 0) {
      var card_current_page = that.data.card_current_page + 1;
      that.setData({
        card_current_page: card_current_page
      })
      if (card_current_page <= that.data.card_total_page) {
        // 获取开卡记录
        that.getOpenCard(that.data.card_search, '0', card_current_page, '10')
      }
    } else if (that.data.current_index == 1) {
      var loss_current_page = that.data.loss_current_page + 1;
      that.setData({
        loss_current_page: loss_current_page
      })
      if (loss_current_page <= that.data.loss_total_page) {
        // 获取挂失卡记录
        that.getOpenCard(that.data.card_search, '1', loss_current_page, '10')
      }
    }
  },

  // 监听input
  watchCardInput: function (e) {
    var that = this;
    that.data.card_search = e.detail.value
  },

  // 点击确定按钮
  confirmSearch: function () {
    var that = this;
    if (that.data.current_index == 0) {
      that.data.card_current_page = 1;
      that.data.card_total_page = '';
      that.data.card_list = [];
      // 获取开卡记录
      that.getOpenCard(that.data.card_search, '0', 1, '10')
    } else if (that.data.current_index == 1) {
      that.data.loss_current_page = 1;
      that.data.loss_total_page = '';
      that.data.loss_list = [];
      // 获取挂失卡记录
      that.getOpenCard(that.data.card_search, '1', 1, '10')
    }
  },

  // 点击tab
  cardTab: function (e) {
    var that = this;
    that.setData({
      current_index: e.currentTarget.dataset.index
    })
    if (e.currentTarget.dataset.index == 0) {
      that.data.card_current_page = 1;
      that.data.card_total_page = '';
      that.data.card_list = [];
      // 获取开卡记录
      that.getOpenCard(that.data.card_search, '0', 1, '10')
    } else if (e.currentTarget.dataset.index == 1) {
      that.data.loss_current_page = 1;
      that.data.loss_total_page = '';
      that.data.loss_list = [];
      // 获取挂失卡记录
      that.getOpenCard(that.data.card_search, '1', 1, '10')
    }
  },

  // 点击挂失按钮
  lossCard: function (e) {
    var that = this;
    wx.showModal({
      title: '挂失',
      content: '确定挂失此水卡吗？',
      confirmText: '挂失',
      confirmColor: '#da5a5a',
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            cardId: e.currentTarget.dataset.cardid,
            type: '1'
          }
          server.postData(sendData, '/waterCards/updateStatus', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '挂失卡成功！',
                icon: 'none'
              })
              that.data.card_list.splice(e.currentTarget.dataset.index, 1);
              if (that.data.card_list.length != 0) {
                that.data.card_list_status = true
              } else {
                that.data.card_list_status = false
              }
              that.setData({
                card_list: that.data.card_list,
                card_list_status: that.data.card_list_status
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  // 点击同步按钮
  synchCard: function (e) {
    var that = this;
    wx.showModal({
      title: '同步',
      content: '确定余额同步吗？',
      confirmText: '同步',
      confirmColor: '#52b260',
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            money: e.currentTarget.dataset.money,
            cardId: e.currentTarget.dataset.cardid,
            handtype: '余额同步'
          }
          server.postData(sendData, '/waterCards/syncAccount', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '余额同步成功！',
                icon: 'none'
              })
              that.data.card_list[e.currentTarget.dataset.index].deviceMoneyDeal = that.data.card_list[e.currentTarget.dataset.index].countMoneyDeal
              that.setData({
                card_list: that.data.card_list
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  // 点击恢复按钮
  regainCard: function (e) {
    var that = this;
    wx.showModal({
      title: '恢复',
      content: '确定恢复已注销的水卡吗？',
      confirmText: '恢复',
      confirmColor: '#52c6a7',
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            cardId: e.currentTarget.dataset.cardid,
            type: '0'
          }
          server.postData(sendData, '/waterCards/updateStatus', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '恢复成功！',
                icon: 'none'
              })
              that.data.loss_list.splice(e.currentTarget.dataset.index, 1);
              if (that.data.loss_list.length != 0) {
                that.data.loss_list_status = true
              } else {
                that.data.loss_list_status = false
              }
              that.setData({
                loss_list: that.data.loss_list,
                loss_list_status: that.data.loss_list_status
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_status) {
      if (that.data.current_index == 0) {
        that.data.card_current_page = 1;
        that.data.card_total_page = '';
        that.data.card_list = [];
        // 获取开卡记录
        that.getOpenCard(that.data.card_search, '0', 1, '10')
      } else if (that.data.current_index == 1) {
        that.data.loss_current_page = 1;
        that.data.loss_total_page = '';
        that.data.loss_list = [];
        // 获取挂失卡记录
        that.getOpenCard(that.data.card_search, '1', 1, '10')
      }
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_status = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})