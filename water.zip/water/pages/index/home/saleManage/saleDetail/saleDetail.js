// pages/index/home/saleManage/saleDetail/saleDetail.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '详情', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    user_infor: '',
    sale_name: '',
    sale_infor: '',
    loading_layer_status: 'hidden',
    judge_page_status: false,
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.sale_name = options.name
    that.data.user_infor = wx.getStorageSync('user')
    // 获取促销员信息
    that.getSale()
  },

  // 获取促销员信息
  getSale: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      roleId: '3',
      username: that.data.sale_name,
      page: 1,
      limit: '1'
    }
    server.postData(sendData, '/users/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        res.data[0].normDeal = (Number(res.data[0].norm) / 100).toFixed(2)
        res.data[0].acc_isDeal = (Number(res.data[0].acc_is) / 100).toFixed(2)
        res.data[0].proportionDeal = Number(res.data[0].proportion) / 100
        // res.data[0].remNormDeal = (Number(res.data[0].remNorm) / 100).toFixed(2)
        // res.data[0].saleNormDeal = ((Number(res.data[0].norm) - Number(res.data[0].remNorm)) / 100).toFixed(2)
        res.data[0].acc_noDeal = (Number(res.data[0].acc_no) * (res.data[0].proportion / 100 / 100) / 100).toFixed(2)
        res.data[0].account = Number(res.data[0].acc_no) * (res.data[0].proportion / 100 / 100) * 1000 / 1000 / 100
        res.data[0].saleCountMoneyDeal = (Number(res.data[0].saleCountMoney) / 100).toFixed(2)
        that.setData({
          sale_infor: res.data[0],
        })
      }
    })
  },

  // 点击结算按钮
  settleBtn: function (e) {
    var that = this;
    wx.showModal({
      title: '收益结算',
      content: '结算金额：' + that.data.sale_infor.account + '元，确定结算吗？',
      confirmText: '结算',
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          var account = that.data.sale_infor.account * 10000 * 100 / 10000
          var sendData = {
            account: account,
            acc_time: that.data.sale_infor.accTime,
            userId: that.data.sale_infor.id,
            accUserId: that.data.user_infor.id,
          }
          server.postFData(sendData, '/userAccounts/updateuserAccount', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '结算成功！',
                icon: 'none'
              })
              // 获取促销员信息
              that.getSale()
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_status) {
      // 获取促销员信息
      that.getSale()
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_status = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})