// pages/index/home/saleManage/saleEdit/saleEdit.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '编辑促销员', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    sale_name: '',
    sale_infor: '',
    area_list: [],
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.sale_name = options.name
    // 获取促销员信息
    that.getSale()
  },

  // 获取促销员信息
  getSale: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      roleId: '3',
      username: that.data.sale_name,
      page: 1,
      limit: '1'
    }
    server.postData(sendData, '/users/findList', function (res) {
      // console.log(res)
      if (res.code == 200) {
        res.data[0].normDeal = res.data[0].norm / 100
        res.data[0].proportionDeal = res.data[0].proportion / 100
        that.setData({
          sale_infor: res.data[0],
        })
        // 获取区域列表
        that.getArea()
      }
    })
  },

  // 获取区域列表
  getArea: function () {
    var that = this;
    var sendData = {
      page: 1,
      limit: '10000'
    }
    server.postData(sendData, '/areas/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        res.data.filter(function (v) {
          if (that.data.sale_infor.areaIds != null) {
            if (that.data.sale_infor.areaIds.split(',').indexOf(v.id.toString()) > -1) {
              v.status = true
            } else {
              v.status = false
            }
          } else {
            v.status = false
          }
        })
        that.setData({
          area_list: res.data,
        })
      }
    })
  },

  // 点击区域列表
  areaTab: function (e) {
    var that = this;
    that.data.area_list[e.currentTarget.dataset.index].status = !that.data.area_list[e.currentTarget.dataset.index].status
    that.setData({
      area_list: that.data.area_list
    })
  },

  // 点击确定按钮
  editSubmit: function (e) {
    var that = this;
    var phone_reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
    var area_id = [];
    for (var i = 0; i < that.data.area_list.length; i++) {
      if (that.data.area_list[i].status) {
        area_id.push(that.data.area_list[i].id)
      }
    }
    if (e.detail.value.sale == '') {
      wx.showToast({
        title: '请输入促销员名称！',
        icon: 'none'
      })
    } else if (e.detail.value.phone == '') {
      wx.showToast({
        title: '请输入手机号！',
        icon: 'none'
      })
    } else if (!phone_reg.test(e.detail.value.phone)) {
      wx.showToast({
        title: '请输入正确的手机号！',
        icon: 'none'
      })
    } else if (area_id.length == 0) {
      wx.showToast({
        title: '请先选择区域！',
        icon: 'none'
      })
    } else if (e.detail.value.limit == '') {
      wx.showToast({
        title: '请输入限额额度！',
        icon: 'none'
      })
    } else if (Number(e.detail.value.limit) <= 0) {
      wx.showToast({
        title: '限额额度只能是大于0的数！',
        icon: 'none'
      })
    } else if (e.detail.value.percent == '') {
      wx.showToast({
        title: '请输入提成比例！',
        icon: 'none'
      })
    } else if (Number(e.detail.value.percent) < 0 || Number(e.detail.value.percent) > 100) {
      wx.showToast({
        title: '提成比例只能是0-100之间的数！',
        icon: 'none'
      })
    } else {
      if (e.detail.value.percent.split('.').length > 1) {
        if (e.detail.value.percent.split('.')[1].length == 1) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            id: that.data.sale_infor.id,
            roleId: '3',
            nickname: e.detail.value.sale,
            username: e.detail.value.phone,
            phone: e.detail.value.phone,
            norm: Number(e.detail.value.limit) * 100,
            areaIds: area_id.toString(),
            proportion: (Number(e.detail.value.percent) * 100).toFixed(2).split('.')[0]
          }
          // 编辑促销员
          that.editSale(sendData)
        } else {
          wx.showToast({
            title: '提成比例最多只能输入一位小数！',
            icon: 'none'
          })
        }
      } else {
        that.setData({
          loading_layer_status: 'show'
        })
        var sendData = {
          id: that.data.sale_infor.id,
          roleId: '3',
          nickname: e.detail.value.sale,
          username: e.detail.value.phone,
          phone: e.detail.value.phone,
          norm: Number(e.detail.value.limit) * 100,
          areaIds: area_id.toString(),
          proportion: (Number(e.detail.value.percent) * 100).toFixed(2).split('.')[0]
        }
        // 编辑促销员
        that.editSale(sendData)
      }
    }
  },

  // 编辑促销员
  editSale: function (sendData) {
    var that = this;
    server.postFData(sendData, '/users/updateUser', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        wx.showToast({
          title: '编辑促销员成功！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.navigateBack({
            delta: 1
          })
        }, 1500)
      } else {
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})