// pages/index/home/rechargeRecord/rechargeRecord.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')
var dateTimePicker = require('../../../../utils/dateTimePicker.js');
var animation = wx.createAnimation({
  duration: 500,
  timingFunction: 'ease-in-out',
});

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '充值记录', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    aside_width: app.globalData.windowWidth * 0.63,
    current_page: 1,
    total_page: '',
    recharge_record_status: true,
    recharge_record: [],
    startYear: 2010,
    endYear: 2030,
    dateTime1: '',
    dateTimeArray1: '',
    dateTime2: '',
    dateTimeArray2: '',
    start_time: '',
    end_time: '',
    card_num: '',
    use_type: '',
    device_id: '',
    wx_id: '',
    loading_layer_status: 'hidden',
    cate_list: [],
    cate_index: -1,
    filter_layer_flag: 'hidden',
    filter_item_status: [true],
    _SEVENFLAG:true,
    _SEVENmsg:""
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      _SEVENFLAG: true
    });
    // console.log(options)
    var obj1 = dateTimePicker.dateTimePicker(that.data.startYear, that.data.endYear);
    var obj2 = dateTimePicker.dateTimePicker(that.data.startYear, that.data.endYear);
    
    obj1.dateTime[3] = 0
    obj1.dateTime[4] = 0
    obj1.dateTime[5] = 0
    that.data.start_time = dateTimePicker.SevenDaysAgos
    that.data.end_time = util.formatYTime(new Date())
    // console.log(that.data.start_time,that.data._SEVENFLAG)
    // console.log(that.data.end_time)
    that.setData({
      dateTime1: obj1.dateTime,
      dateTimeArray1: obj1.dateTimeArray,
      dateTime2: obj2.dateTime,
      dateTimeArray2: obj2.dateTimeArray,
      _SEVENmsg: dateTimePicker.SevenDaysAgos
    });
    that.data.device_id = options.deviceid
    that.data.wx_id = options.wxid
    that.setData({
      card_num: options.cardid
    })
    // 获取充值记录列表
    that.getRechargeRecord(that.data.card_num, that.data.start_time, that.data.end_time, that.data.use_type, 1, '20')
  },

  // 获取充值记录列表
  getRechargeRecord: function (cardNum, startTime, endTime, useType, page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      deviceId: that.data.device_id,
      wxUserId: that.data.wx_id,
      search: cardNum,
      sTime: startTime,
      eTime: endTime,
      useType: useType,
      page: page,
      limit: limit,
      handTypes: '1'
    }
    server.postData(sendData, '/paylogs/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].status = false
            res.data[i].moneyDeal = (res.data[i].money / 100).toFixed(2)
            res.data[i].giveMoneyDeal = (res.data[i].giveMoney / 100).toFixed(2)
            res.data[i].cardMoneyDeal = (res.data[i].cardMoney / 100).toFixed(2)
            res.data[i].accountDeal = (res.data[i].account / 100).toFixed(2)
            res.data[i].createTimeDeal = res.data[i].createTime.split(' ')[0] + '\n' + res.data[i].createTime.split(' ')[1]
          }
          var recharge_record = that.data.recharge_record.concat(res.data);
          that.setData({
            recharge_record: recharge_record,
            recharge_record_status: true
          })
          var count = res.count;
          var total_page = count / 20 < 1 ? 0 : count / 20;
          if (count % 20 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            recharge_record: [],
            recharge_record_status: false
          })
        }
      }
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    var current_page = that.data.current_page + 1;
    that.setData({
      current_page: current_page
    })
    if (current_page <= that.data.total_page) {
      // 获取充值记录列表
      that.getRechargeRecord(that.data.card_num, that.data.start_time, that.data.end_time, that.data.use_type, current_page, '20')
    }
  },

  // 监听充值记录input
  watchRechargeInput: function (e) {
    var that = this;
    that.data.card_num = e.detail.value
  },

  // 点击确定按钮
  confirmSearch: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.recharge_record = [];
    if ((new Date(that.data.end_time.replace(/-/g, "/"))).getTime() >= (new Date(that.data.start_time.replace(/-/g, "/"))).getTime()) {
      // 获取充值记录列表
      that.getRechargeRecord(that.data.card_num, that.data.start_time, that.data.end_time, that.data.use_type, 1, '20')
    } else {
      wx.showToast({
        title: '结束时间必须大于开始时间！',
        icon: 'none'
      })
    }
  },

  // 监听开始日期变化
  changeDateTime1(e) {
    
    var that = this;
    that.data.start_time = that.data.dateTimeArray1[0][e.detail.value[0]] + '-' + that.data.dateTimeArray1[1][e.detail.value[1]] + '-' + that.data.dateTimeArray1[2][e.detail.value[2]] + ' ' + that.data.dateTimeArray1[3][e.detail.value[3]] + ':' + that.data.dateTimeArray1[4][e.detail.value[4]] + ':' + that.data.dateTimeArray1[5][e.detail.value[5]]
    that.setData({
      dateTime1: e.detail.value,
      _SEVENFLAG:false
    });
  },

  // 监听结束日期变化
  changeDateTime2(e) {
    var that = this;
    that.data.end_time = that.data.dateTimeArray2[0][e.detail.value[0]] + '-' + that.data.dateTimeArray2[1][e.detail.value[1]] + '-' + that.data.dateTimeArray2[2][e.detail.value[2]] + ' ' + that.data.dateTimeArray2[3][e.detail.value[3]] + ':' + that.data.dateTimeArray2[4][e.detail.value[4]] + ':' + that.data.dateTimeArray2[5][e.detail.value[5]]
    that.setData({
      dateTime2: e.detail.value,
    });
  },

  // 点击筛选按钮
  filterBoxPopup: function () {
    var that = this;
    // 获取操作类型列表
    that.getOperaCate()
    animation.translateX(-that.data.aside_width).step();
    that.setData({
      filter_animation: animation.export(),
      filter_layer_flag: 'show'
    });
  },

  // 获取操作类型列表
  getOperaCate: function () {
    var that = this;
    var sendData = {
      type: 'useType'
    }
    server.postData(sendData, '/dicts/getDict', function (res) {
      // console.log(res)
      if (res.code == 200) {
        that.setData({
          cate_list: res.data
        })
      }
    })
  },

  // 点击遮罩层
  filterBoxDismiss: function () {
    var that = this;
    animation.translateX(that.data.aside_width).step();
    that.setData({
      filter_animation: animation.export(),
      filter_layer_flag: 'hidden'
    });
  },

  // 点击筛选箭头
  filterStatus: function (e) {
    var that = this;
    that.data.filter_item_status[Number(e.currentTarget.dataset.index)] = !that.data.filter_item_status[Number(e.currentTarget.dataset.index)]
    that.setData({
      filter_item_status: that.data.filter_item_status
    })
  },

  // 点击类型tab
  cateTab: function (e) {
    var that = this;
    that.setData({
      cate_index: e.currentTarget.dataset.index
    })
  },

  // 点击筛选按钮
  fifterBtn: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.recharge_record = [];
    if (that.data.cate_index != -1) {
      that.data.use_type = that.data.cate_list[that.data.cate_index].k
    } else {
      that.data.use_type = ''
    }
    // 获取充值记录列表
    that.getRechargeRecord(that.data.card_num, that.data.start_time, that.data.end_time, that.data.use_type, 1, '20')
    that.filterBoxDismiss()
  },

  // 点击重置按钮
  resetBtn: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.recharge_record = [];
    that.data.use_type = '';
    that.setData({
      cate_index: -1,
    })
    // 获取充值记录列表
    that.getRechargeRecord(that.data.card_num, that.data.start_time, that.data.end_time, that.data.use_type, 1, '20')
    that.filterBoxDismiss()
  },

  // 点击详情按钮
  lookDetail: function (e) {
    var that = this;
    that.data.recharge_record[e.currentTarget.dataset.index].status = !that.data.recharge_record[e.currentTarget.dataset.index].status
    that.setData({
      recharge_record: that.data.recharge_record
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})