// pages/index/home/cardManage/cardManage.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')
var animation = wx.createAnimation({
  duration: 500,
  timingFunction: 'ease-in-out',
});

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '水卡管理', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    aside_width: app.globalData.windowWidth * 0.6,
    current_page: 1,
    total_page: '',
    card_list_status: true,
    card_list: [],
    card_search: '',
    phone_search: '',
    name_search: '',
    status_search: '',
    cate_search: '',
    filter_layer_flag: 'hidden',
    cate_list: [],
    cate_index: -1,
    status_list: [],
    status_index: -1,
    filter_item_status: [true, true],
    loading_layer_status: 'hidden',
    judge_page_status: false,
    equip_item_status: false,
    sort_status: '',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取卡类型
    that.getCardCate()
  },

  // 获取水卡管理数据
  getCard: function (desc, cardId, phone, name, status, cate, page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      desc: desc,
      cardId: cardId,
      phone: phone,
      uname: name,
      status: status,
      cardType: cate,
      page: page,
      limit: limit,
    }
    server.postData(sendData, '/waterCards/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].flag = false;
            res.data[i].countMoneyDeal = (res.data[i].countMoney / 100).toFixed(2)
            res.data[i].deviceMoneyDeal = (res.data[i].deviceMoney / 100).toFixed(2)
          }
          var card_list = that.data.card_list.concat(res.data);
          that.setData({
            card_list: card_list,
            card_list_status: true
          })
          var count = res.count;
          var total_page = count / 15 < 1 ? 0 : count / 15;
          if (count % 15 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            card_list: [],
            card_list_status: false
          })
        }
      }
    })
  },

  // 点击切换图标
  changeTab: function () {
    var that = this;
    that.data.equip_item_status = !that.data.equip_item_status
    that.setData({
      equip_item_status: that.data.equip_item_status
    })
  },

  // 点击第一行数据
  lookDetail: function (e) {
    var that = this;
    that.data.card_list[e.currentTarget.dataset.index].flag = !that.data.card_list[e.currentTarget.dataset.index].flag
    that.setData({
      card_list: that.data.card_list
    })
  },

  // 点击上报余额进行排序
  sortByBalnace: function () {
    var that = this;
    if (that.data.sort_status != '') {
      that.data.sort_status = that.data.sort_status == '1' ? '2' : '1'
      that.setData({
        sort_status: that.data.sort_status
      })
      that.data.current_page = 1;
      that.data.total_page = '';
      that.data.card_list = [];
      // 获取水卡管理数据
      that.getCard(that.data.sort_status, that.data.card_search, that.data.phone_search, that.data.name_search, that.data.status_search, that.data.cate_search, 1, '15')
    } else {
      that.data.sort_status = '1'
      that.setData({
        sort_status: that.data.sort_status
      })
      that.data.current_page = 1;
      that.data.total_page = '';
      that.data.card_list = [];
      // 获取水卡管理数据
      that.getCard(that.data.sort_status, that.data.card_search, that.data.phone_search, that.data.name_search, that.data.status_search, that.data.cate_search, 1, '15')
    }
  },

  // 点击明细按钮
  skipDetail: function (e) {
    var that = this;
    wx.navigateTo({
      url: '/pages/index/home/cardManage/details/details?cardid=' + e.currentTarget.dataset.cardid,
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    var current_page = that.data.current_page + 1;
    that.setData({
      current_page: current_page
    })
    if (current_page <= that.data.total_page) {
      // 获取水卡管理数据
      that.getCard(that.data.sort_status, that.data.card_search, that.data.phone_search, that.data.name_search, that.data.status_search, that.data.cate_search, current_page, '15')
    }
  },

  // 监听卡号input
  watchCardInput: function (e) {
    var that = this;
    that.data.card_search = e.detail.value
  },

  // 监听手机号input
  watchPhoneInput: function (e) {
    var that = this;
    that.data.phone_search = e.detail.value
  },

  // 监听姓名input
  watchNameInput: function (e) {
    var that = this;
    that.data.name_search = e.detail.value
  },

  // 点击确定按钮
  confirmSearch: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.card_list = [];
    // 获取水卡管理数据
    that.getCard(that.data.sort_status, that.data.card_search, that.data.phone_search, that.data.name_search, that.data.status_search, that.data.cate_search, 1, '15')
  },

  // 点击筛选按钮
  filterBoxPopup: function () {
    var that = this;
    animation.translateX(-that.data.aside_width).step();
    that.setData({
      filter_animation: animation.export(),
      filter_layer_flag: 'show'
    });
  },

  // 获取卡类型
  getCardCate: function () {
    var that = this;
    server.getData('', '/dicts?type=cardType', function (res) {
      // console.log(res)
      that.setData({
        cate_list: res
      })
      // 获取卡状态
      that.getCardStatus()
    })
  },

  // 获取卡状态
  getCardStatus: function () {
    var that = this;
    server.getData('', '/dicts?type=cardstatus', function (res) {
      // console.log(res)
      for (var i = 0; i < res.length; i++) {
        if (res[i].val == '正常') {
          that.data.status_index = i
        }
      }
      that.setData({
        status_list: res,
        status_index: that.data.status_index
      })
      that.data.status_search = that.data.status_list[that.data.status_index].k
      // 获取水卡管理数据
      that.getCard(that.data.sort_status, that.data.card_search, that.data.phone_search, that.data.name_search, that.data.status_search, that.data.cate_search, 1, '15')
    })
  },

  // 点击遮罩层
  filterBoxDismiss: function () {
    var that = this;
    animation.translateX(that.data.aside_width).step();
    that.setData({
      filter_animation: animation.export(),
      filter_layer_flag: 'hidden'
    });
  },

  // 点击筛选箭头
  filterStatus: function (e) {
    var that = this;
    that.data.filter_item_status[Number(e.currentTarget.dataset.index)] = !that.data.filter_item_status[Number(e.currentTarget.dataset.index)]
    that.setData({
      filter_item_status: that.data.filter_item_status
    })
  },

  // 点击类型tab
  cateTab: function (e) {
    var that = this;
    that.setData({
      cate_index: e.currentTarget.dataset.index
    })
  },

  // 点击状态tab
  statusTab: function (e) {
    var that = this;
    that.setData({
      status_index: e.currentTarget.dataset.index
    })
  },

  // 点击筛选按钮
  fifterBtn: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.card_list = [];
    if (that.data.cate_index != -1) {
      that.data.cate_search = that.data.cate_list[that.data.cate_index].k
    } else {
      that.data.cate_search = ''
    }
    if (that.data.status_index != -1) {
      that.data.status_search = that.data.status_list[that.data.status_index].k
    } else {
      that.data.status_search = ''
    }
    // 获取水卡管理数据
    that.getCard(that.data.sort_status, that.data.card_search, that.data.phone_search, that.data.name_search, that.data.status_search, that.data.cate_search, 1, '15')
    that.filterBoxDismiss()
  },

  // 点击重置按钮
  resetBtn: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.card_list = [];
    that.data.cate_search = '';
    that.data.status_search = '';
    that.setData({
      cate_index: -1,
      status_index: -1,
    })
    // 获取水卡管理数据
    that.getCard(that.data.sort_status, that.data.card_search, that.data.phone_search, that.data.name_search, that.data.status_search, that.data.cate_search, 1, '15')
    that.filterBoxDismiss()
  },

  // 点击挂失按钮
  lossCard: function (e) {
    var that = this;
    wx.showModal({
      title: '挂失',
      content: '确定挂失此水卡吗？',
      confirmText: '挂失',
      confirmColor: '#da5a5a',
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            cardId: e.currentTarget.dataset.cardid,
            type: '1'
          }
          server.postData(sendData, '/waterCards/updateStatus', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '挂失卡成功！',
                icon: 'none'
              })
              that.data.card_list[e.currentTarget.dataset.index].status = '挂失'
              that.setData({
                card_list: that.data.card_list
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  // 点击同步按钮
  synchCard: function (e) {
    var that = this;
    wx.showModal({
      title: '同步',
      content: '确定余额同步吗？',
      confirmText: '同步',
      confirmColor: '#52b260',
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            money: e.currentTarget.dataset.money,
            cardId: e.currentTarget.dataset.cardid,
            handtype: '余额同步'
          }
          server.postData(sendData, '/waterCards/syncAccount', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '余额同步成功！',
                icon: 'none'
              })
              that.data.card_list[e.currentTarget.dataset.index].deviceMoneyDeal = that.data.card_list[e.currentTarget.dataset.index].countMoneyDeal
              that.setData({
                card_list: that.data.card_list
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  // 点击恢复按钮
  regainCard: function (e) {
    var that = this;
    wx.showModal({
      title: '恢复',
      content: '确定恢复已注销的水卡吗？',
      confirmText: '恢复',
      confirmColor: '#52c6a7',
      success(res) {
        if (res.confirm) {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            cardId: e.currentTarget.dataset.cardid,
            type: '0'
          }
          server.postData(sendData, '/waterCards/updateStatus', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '恢复成功！',
                icon: 'none'
              })
              that.data.card_list[e.currentTarget.dataset.index].status = '正常'
              that.setData({
                card_list: that.data.card_list
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_status) {
      that.data.current_page = 1;
      that.data.total_page = '';
      that.data.card_list = [];
      // 获取水卡管理数据
      that.getCard(that.data.sort_status, that.data.card_search, that.data.phone_search, that.data.name_search, that.data.status_search, that.data.cate_search, 1, '15')
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_status = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})