// pages/index/home/cardManage/cardDetail/cardDetail.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '水卡详情', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    card_id: '',
    card_infor: '',
    loading_layer_status: 'hidden',
    judge_page_status: false
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.card_id = options.cardid
    // 获取水卡详情
    that.getCardDetail()
  },

  // 获取水卡详情
  getCardDetail: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      cardId: that.data.card_id,
      page: 1,
      limit: '1'
    }
    server.postData(sendData, '/waterCards/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        res.data[0].countMoneyDeal = (res.data[0].countMoney / 100).toFixed(2)
        res.data[0].deviceMoneyDeal = (res.data[0].deviceMoney / 100).toFixed(2)
        if (res.data[0].areaNames != null) {
          res.data[0].areaNamesDeal = res.data[0].areaNames.split(',')
          if (res.data[0].areaNamesDeal[res.data[0].areaNamesDeal.length - 1] == '') {
            res.data[0].areaNamesDeal.pop()
          }
          res.data[0].areaNamesDeal = res.data[0].areaNamesDeal.toString()
        } else {
          res.data[0].areaNamesDeal = '无'
        }
        that.setData({
          card_infor: res.data[0]
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_status) {
      // 获取水卡详情
      that.getCardDetail()
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_status = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})