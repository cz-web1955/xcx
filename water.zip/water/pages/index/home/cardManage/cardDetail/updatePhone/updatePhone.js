// pages/index/home/cardManage/cardDetail/updatePhone/updatePhone.js
var app = getApp();
// 引入request.js
var server = require('../../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '修改手机号', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    card_infor: '',
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      card_infor: options
    })
  },

  // 点击确定修改按钮
  updateSubmit: function (e) {
    var that = this;
    var phone_reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
    if (!phone_reg.test(e.detail.value.newPhone)) {
      wx.showToast({
        title: '请输入正确的手机号！',
        icon: 'none'
      })
    } else {
      that.setData({
        loading_layer_status: 'show'
      })
      var sendData = {
        cardId: e.detail.value.cardNum,
        phone: e.detail.value.newPhone,
        uname: e.detail.value.uname
      }
      server.postData(sendData, '/waterCards/updateCardPhone', function (res) {
        // console.log(res)
        that.setData({
          loading_layer_status: 'hidden'
        })
        if (res.code == 200) {
          wx.showToast({
            title: '修改成功！',
            icon: 'none'
          })
          setTimeout(function () {
            wx.navigateBack({
              delta: 1
            })
          }, 1500)
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})