// pages/index/home/cardManage/details/details.js\
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '明细', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    card_id: '',
    cate_tab: ['消费记录', '充值记录', '修改记录'],
    current_index: 0,
    consume_current_page: 1,
    consume_total_page: '',
    consume_record_status: true,
    consume_record: [],
    recharge_current_page: 1,
    recharge_total_page: '',
    recharge_record_status: true,
    recharge_record: [],
    update_current_page: 1,
    update_total_page: '',
    update_list_status: true,
    update_list: [],
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // console.log(options)
    that.data.card_id = options.cardid
    // 获取消费记录
    that.getConsumeRecord(1, '30')
  },

  // 获取消费记录
  getConsumeRecord: function (page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      cardId: that.data.card_id,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/consumerLogs/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].status = false;
            res.data[i].accountDeal = (res.data[i].account / 100).toFixed(2)
          }
          var consume_record = that.data.consume_record.concat(res.data);
          that.setData({
            consume_record: consume_record,
            consume_record_status: true
          })
          var count = res.count;
          var consume_total_page = count / 30 < 1 ? 0 : count / 30;
          if (count % 30 == 0) {
            that.data.consume_total_page = consume_total_page;
          } else {
            that.data.consume_total_page = parseInt(consume_total_page) + 1;
          }
        } else {
          that.setData({
            consume_record: [],
            consume_record_status: false
          })
        }
      }
    })
  },

  // 点击消费记录详情按钮
  lookConsumeDetail: function (e) {
    var that = this;
    that.data.consume_record[e.currentTarget.dataset.index].status = !that.data.consume_record[e.currentTarget.dataset.index].status
    that.setData({
      consume_record: that.data.consume_record
    })
  },

  // 获取充值记录
  getRechargeRecord: function (page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      cardId: that.data.card_id,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/paylogs/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].status = false
            res.data[i].moneyDeal = (res.data[i].money / 100).toFixed(2)
            res.data[i].giveMoneyDeal = (res.data[i].giveMoney / 100).toFixed(2)
            res.data[i].cardMoneyDeal = (res.data[i].cardMoney / 100).toFixed(2)
            res.data[i].accountDeal = (res.data[i].account / 100).toFixed(2)
          }
          var recharge_record = that.data.recharge_record.concat(res.data);
          that.setData({
            recharge_record: recharge_record,
            recharge_record_status: true
          })
          var count = res.count;
          var recharge_total_page = count / 30 < 1 ? 0 : count / 30;
          if (count % 30 == 0) {
            that.data.recharge_total_page = recharge_total_page;
          } else {
            that.data.recharge_total_page = parseInt(recharge_total_page) + 1;
          }
        } else {
          that.setData({
            recharge_record: [],
            recharge_record_status: false
          })
        }
      }
    })
  },

  // 点击充值记录详情按钮
  lookRechargeDetail: function (e) {
    var that = this;
    that.data.recharge_record[e.currentTarget.dataset.index].status = !that.data.recharge_record[e.currentTarget.dataset.index].status
    that.setData({
      recharge_record: that.data.recharge_record
    })
  },

  // 获取修改记录
  getUpdateRecord: function (page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      cardId: that.data.card_id,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/syncCards/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].status = false;
            res.data[i].amountDeal = (res.data[i].amount / 100).toFixed(2)
            res.data[i].oldamountDeal = (res.data[i].oldamount / 100).toFixed(2)
          }
          var update_list = that.data.update_list.concat(res.data);
          that.setData({
            update_list: update_list,
            update_list_status: true
          })
          var count = res.count;
          var update_total_page = count / 30 < 1 ? 0 : count / 30;
          if (count % 30 == 0) {
            that.data.update_total_page = update_total_page;
          } else {
            that.data.update_total_page = parseInt(update_total_page) + 1;
          }
        } else {
          that.setData({
            update_list: [],
            update_list_status: false
          })
        }
      }
    })
  },

  // 点击修改记录详情按钮
  lookUpdateDetail: function (e) {
    var that = this;
    that.data.update_list[e.currentTarget.dataset.index].status = !that.data.update_list[e.currentTarget.dataset.index].status
    that.setData({
      update_list: that.data.update_list
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    if (that.data.current_index == 0) {
      var consume_current_page = that.data.consume_current_page + 1;
      that.setData({
        consume_current_page: consume_current_page
      })
      if (consume_current_page <= that.data.consume_total_page) {
        // 获取消费记录
        that.getConsumeRecord(consume_current_page, '30')
      }
    } else if (that.data.current_index == 1) {
      var recharge_current_page = that.data.recharge_current_page + 1;
      that.setData({
        recharge_current_page: recharge_current_page
      })
      if (recharge_current_page <= that.data.recharge_total_page) {
        // 获取充值记录
        that.getRechargeRecord(recharge_current_page, '30')
      }
    } else if (that.data.current_index == 2) {
      var update_current_page = that.data.update_current_page + 1;
      that.setData({
        update_current_page: update_current_page
      })
      if (update_current_page <= that.data.update_total_page) {
        // 获取修改记录
        that.getUpdateRecord(update_current_page, '30')
      }
    }
  },

  // 点击类别tab 
  cateTab: function (e) {
    var that = this;
    that.setData({
      current_index: e.currentTarget.dataset.index
    })
    if (e.currentTarget.dataset.index == 0) {
      that.data.consume_current_page = 1;
      that.data.consume_total_page = '';
      that.data.consume_record = [];
      // 获取消费记录
      that.getConsumeRecord(1, '30')
    } else if (e.currentTarget.dataset.index == 1) {
      that.data.recharge_current_page = 1;
      that.data.recharge_total_page = '';
      that.data.recharge_record = [];
      // 获取充值记录
      that.getRechargeRecord(1, '30')
    } else if (e.currentTarget.dataset.index == 2) {
      that.data.update_current_page = 1;
      that.data.update_total_page = '';
      that.data.update_list = [];
      // 获取修改记录
      that.getUpdateRecord(1, '30')
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})