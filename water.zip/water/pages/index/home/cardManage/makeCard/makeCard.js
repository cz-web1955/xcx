// pages/index/mine/lossCard/makeCard/makeCard.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '补卡', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    card_infor: '',
    card_num: '',
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    console.log(options)
    options.balanceDeal = (Number(options.balance) / 100).toFixed(2)
    that.setData({
      card_infor: options
    })
  },

  // 点击扫码按钮
  scanCode: function (e) {
    var that = this;
    wx.scanCode({
      success: function (res) {
        that.setData({
          card_num: res.result
        })
      }
    })
  },

  // 点击确定按钮
  makeSubmit: function (e) {
    var that = this;
    if (e.detail.value.newNum == '') {
      wx.showToast({
        title: '请输入新卡卡号！',
        icon: 'none'
      })
    } else {
      that.setData({
        loading_layer_status: 'show'
      })
      var sendData = {
        oldCardId: e.detail.value.oldNum,
        cardId: e.detail.value.newNum,
      }
      server.postData(sendData, '/waterCards/resetNewCard', function (res) {
        // console.log(res)
        that.setData({
          loading_layer_status: 'hidden'
        })
        if (res.code == 200) {
          wx.showToast({
            title: '补卡成功！',
            icon: 'none'
          })
          setTimeout(function () {
            wx.navigateBack({
              delta: 1
            })
          }, 1500)
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})