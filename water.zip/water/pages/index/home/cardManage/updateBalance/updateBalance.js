// pages/index/home/cardManage/updateBalance/updateBalance.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '修改余额', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    card_infor: '',
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      card_infor: options
    })
  },

  // 点击确定修改按钮
  updateSubmit: function (e) {
    var that = this;
    if (e.detail.value.updateBalance == '') {
      wx.showToast({
        title: '请输入修改余额！',
        icon: 'none'
      })
    } else if (Number(e.detail.value.updateBalance) < 0) {
      wx.showToast({
        title: '修改余额只能是大于0的数！',
        icon: 'none'
      })
    } else {
      that.setData({
        loading_layer_status: 'show'
      })
      var update_balance = Number(e.detail.value.updateBalance) * 100
      var sendData = {
        money: update_balance,
        cardId: e.detail.value.cardNum,
        handtype: '余额修改'
      }
      server.postData(sendData, '/waterCards/syncAccount', function (res) {
        // console.log(res)
        that.setData({
          loading_layer_status: 'hidden'
        })
        if (res.code == 200) {
          wx.showToast({
            title: '修改成功！',
            icon: 'none'
          })
          setTimeout(function () {
            wx.navigateBack({
              delta: 1
            })
          }, 1500)
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})