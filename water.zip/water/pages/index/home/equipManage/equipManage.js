// pages/index/home/equipManage/equipManage.js
var app = getApp();
// 引入request.js
var server = require('../../../../utils/request.js')
// 引入util.js
var util = require('../../../../utils/util.js')
var animation = wx.createAnimation({
  duration: 500,
  timingFunction: 'ease-in-out',
});

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '设备管理', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    aside_width: app.globalData.windowWidth * 0.6,
    user_infor: '',
    current_page: 1,
    total_page: '',
    equip_list_status: true,
    equip_list: [],
    filter_layer_flag: 'hidden',
    filter_item_status: [true, true],
    loading_layer_status: 'hidden',
    deviceid_search: '',
    area_search: '',
    type_search: '',
    equip_type: [],
    type_index: -1,
    area_list: [],
    area_index: -1,
    judge_page_status: false,
    equip_item_status: false,
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.user_infor = wx.getStorageSync('user')
    // 获取设备列表
    that.getEquip(that.data.deviceid_search, that.data.type_search, that.data.area_search, 1, '20')
  },

  // 获取设备列表
  getEquip: function (deviceId, deviceType, areaId, page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      deviceId: deviceId,
      deviceType: deviceType,
      areaId: areaId,
      page: page,
      limit: limit,
    }
    server.postData(sendData, '/devices/findList', function (res) {
      console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].flag = false;
          }
          var equip_list = that.data.equip_list.concat(res.data);
          that.setData({
            equip_list_status: true,
            equip_list: equip_list
          })
          var count = res.count;
          var total_page = count / 20 < 1 ? 0 : count / 20;
          if (count % 20 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            equip_list: [],
            equip_list_status: false
          })
        }
      }
    })
  },

  // 点击详情按钮
  lookDetail: function (e) {
    var that = this;
    that.data.equip_list[e.currentTarget.dataset.index].flag = !that.data.equip_list[e.currentTarget.dataset.index].flag
    that.setData({
      equip_list: that.data.equip_list
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    var current_page = that.data.current_page + 1;
    that.setData({
      current_page: current_page
    })
    if (current_page <= that.data.total_page) {
      // 获取设备列表
      that.getEquip(that.data.deviceid_search, that.data.type_search, that.data.area_search, current_page, '20')
    }
  },

  // 监听input
  watchAreaInput: function (e) {
    var that = this;
    that.data.deviceid_search = e.detail.value
  },

  // 点击确定按钮
  confirmSearch: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.equip_list = [];
    // 获取设备列表
    that.getEquip(that.data.deviceid_search, that.data.type_search, that.data.area_search, 1, '20')
  },

  // 点击切换图标
  changeTab: function () {
    var that = this;
    that.data.equip_item_status = !that.data.equip_item_status
    that.setData({
      equip_item_status: that.data.equip_item_status
    })
  },

  // 点击硬币结算
  coinAccountBtn: function (e) {
    var that = this;
    server.getData('', '/count/countDevice/' + e.currentTarget.dataset.deviceid, function (res) {
      // console.log(res)
      if (res.code == 200) {
        var account_detail = res.data
        var account = res.data.noCionMoney
        wx.showModal({
          title: '硬币结算',
          content: '投币金额：' + Number(account) / 100 + '元，确定结算吗？',
          confirmText: '结算',
          success(res) {
            if (res.confirm) {
              var sendData = {
                blanceMoney: account,
                edate: account_detail.acceTime,
                sdate: account_detail.accsTime,
                deviceId: e.currentTarget.dataset.deviceid,
              }
              server.postFData(sendData, '/coinCounts/updatecoinCount', function (res) {
                // console.log(res)
                if (res.code == 200) {
                  wx.showToast({
                    title: '硬币结算成功！',
                    icon: 'none'
                  })
                } else {
                  wx.showToast({
                    title: '硬币结算失败！',
                    icon: 'none'
                  })
                }
              })
            }
          }
        })
      }
    })
  },

  // 点击筛选按钮
  filterBoxPopup: function () {
    var that = this;
    // 获取设备类型
    that.getEquipType()
    // 获取区域列表
    that.getArea()
    animation.translateX(-that.data.aside_width).step();
    that.setData({
      filter_animation: animation.export(),
      filter_layer_flag: 'show'
    });
  },

  // 获取设备类型
  getEquipType: function () {
    var that = this;
    server.getData('', '/dicts?type=devType', function (res) {
      // console.log(res)
      that.setData({
        equip_type: res
      })
    })
  },

  // 获取区域列表
  getArea: function () {
    var that = this;
    var sendData = {
      page: 1,
      limit: '10000'
    }
    server.postData(sendData, '/areas/findList', function (res) {
      // console.log(res)
      if (res.code == 200) {
        that.setData({
          area_list: res.data
        })
      }
    })
  },

  // 点击遮罩层
  filterBoxDismiss: function () {
    var that = this;
    animation.translateX(that.data.aside_width).step();
    that.setData({
      filter_animation: animation.export(),
      filter_layer_flag: 'hidden'
    });
  },

  // 点击筛选箭头
  filterStatus: function (e) {
    var that = this;
    that.data.filter_item_status[Number(e.currentTarget.dataset.index)] = !that.data.filter_item_status[Number(e.currentTarget.dataset.index)]
    that.setData({
      filter_item_status: that.data.filter_item_status
    })
  },

  // 点击类型tab
  typeTab: function (e) {
    var that = this;
    that.setData({
      type_index: e.currentTarget.dataset.index
    })
  },

  // 点击区域tab
  areaTab: function (e) {
    var that = this;
    that.setData({
      area_index: e.currentTarget.dataset.index
    })
  },

  // 点击筛选按钮
  fifterBtn: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.equip_list = [];
    if (that.data.type_index != -1) {
      that.data.type_search = that.data.equip_type[that.data.type_index].k;
    }
    if (that.data.area_index != -1) {
      that.data.area_search = that.data.area_list[that.data.area_index].id;
    }
    // 获取设备列表
    that.getEquip(that.data.deviceid_search, that.data.type_search, that.data.area_search, 1, '20')
    that.filterBoxDismiss()
  },

  // 点击重置按钮
  resetBtn: function () {
    var that = this;
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.equip_list = [];
    that.data.type_search = '';
    that.data.area_search = '';
    that.setData({
      type_index: -1,
      area_index: -1,
    })
    // 获取设备列表
    that.getEquip(that.data.deviceid_search, that.data.type_search, that.data.area_search, 1, '20')
    that.filterBoxDismiss()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_status) {
      that.data.current_page = 1;
      that.data.total_page = '';
      that.data.equip_list = [];
      // 获取设备列表
      that.getEquip(that.data.deviceid_search, that.data.type_search, that.data.area_search, 1, '20')
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_status = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})