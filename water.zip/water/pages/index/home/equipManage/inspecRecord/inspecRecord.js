// pages/index/home/equipManage/inspecRecord/inspecRecord.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '巡检记录', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    device_id: '',
    inspec_list_status: true,
    inspec_list: [],
    loading_layer_status: 'hidden',
    judge_page_status: false,
    icon_url: app.globalData.sendUrl
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      device_id: options.deviceid
    })
    // 获取巡检记录列表
    that.getInspecRecord()
  },

  // 获取巡检记录列表
  getInspecRecord: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      deviceId: that.data.device_id
    }
    server.postData(sendData, '/checkLogs/findDayList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          that.setData({
            inspec_list: res.data,
            inspec_list_status: true
          })
        } else {
          that.setData({
            inspec_list: [],
            inspec_list_status: false
          })
        }
      }
    })
  },

  // 点击图片预览
  previewIcon: function (e) {
    var that = this;
    var icon_list = [];
    for (var i = 0; i < that.data.inspec_list[e.currentTarget.dataset.index].data.length; i++) {
      icon_list.push(app.globalData.sendUrl + that.data.inspec_list[e.currentTarget.dataset.index].data[i].img_url)
    }
    wx.previewImage({
      current: e.currentTarget.dataset.url,
      urls: icon_list
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_status) {
      // 获取巡检记录列表
      that.getInspecRecord()
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_status = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})