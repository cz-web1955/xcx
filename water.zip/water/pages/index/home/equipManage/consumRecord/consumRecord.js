// pages/index/home/equipManage/consumRecord/consumRecord.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '消费统计', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    device_id: '',
    consum_record: '',
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.device_id = options.deviceid
    // 获取消费记录
    that.getConsumRecord()
  },

  // 获取消费记录
  getConsumRecord: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    server.getData('', '/count/countDevice/' + that.data.device_id, function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        res.data.noCionMoneyDeal = (Number(res.data.noCionMoney) / 100).toFixed(2)
        res.data.cardconsumerDeal = (Number(res.data.cardconsumer) / 100).toFixed(2)
        res.data.wxconsumerDeal = (Number(res.data.wxconsumer) / 100).toFixed(2)
        res.data.cionMoneyDeal = (Number(res.data.cionMoney) / 100).toFixed(2)
        res.data.isCionMoneyDeal = (Number(res.data.isCionMoney) / 100).toFixed(2)
        res.data.openMoenyDeal = (Number(res.data.openMoeny) / 100).toFixed(2)
        that.setData({
          consum_record: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})