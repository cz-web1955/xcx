// pages/index/home/equipManage/equipDetail/bindPartner/bindPartner.js
var app = getApp();
// 引入request.js
var server = require('../../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '绑定合伙人', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    device_id: '',
    partner_ids: '',
    partner_list_status: true,
    partner_list: [],
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.device_id = options.deviceid
    that.data.partner_ids = options.ids
    // 获取合伙人列表
    that.getPartner()
  },

  // 获取合伙人列表
  getPartner: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      deviceId: that.data.device_id
    }
    server.postData(sendData, '/devices/findPartner', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          if (that.data.partner_ids == 'null' || that.data.partner_ids == '') {
            for (var i = 0; i < res.data.length; i++) {
              res.data[i].status = false
            }
          } else {
            var partner_ids = that.data.partner_ids.split(',')
            res.data.filter(function (v) {
              if (partner_ids.indexOf(v.id.toString()) > -1) {
                v.status = true
              } else {
                v.status = false
              }
            })
          }
          that.setData({
            partner_list: res.data,
            partner_list_status: true
          })
        } else {
          that.setData({
            partner_list: [],
            partner_list_status: false
          })
        }
      }
    })
  },

  // 点击合伙人列表
  partnerTab: function (e) {
    var that = this;
    that.data.partner_list[e.currentTarget.dataset.index].status = !that.data.partner_list[e.currentTarget.dataset.index].status
    that.setData({
      partner_list: that.data.partner_list
    })
  },

  // 点击确定按钮
  confirmBtn: function (e) {
    var that = this;
    var ids_arr = [];
    var ids_index = [];
    var selected_index = [];
    var percent = [];
    var percent_check = [];
    for (var i = 0; i < that.data.partner_list.length; i++) {
      if (that.data.partner_list[i].status) {
        ids_arr.push(that.data.partner_list[i].id)
        ids_index.push(i)
      }
    }
    if (ids_arr.length != 0) {
      for (var i in e.detail.value) {
        if (e.detail.value.hasOwnProperty(i)) {
          if (e.detail.value[i] != '') {
            selected_index.push(Number(i.split('_')[1]))
            percent.push(e.detail.value[i])
            if (Number(e.detail.value[i]) < 0 || Number(e.detail.value[i]) > 100) {
              percent_check.push(e.detail.value[i])
            } else {
              if (e.detail.value[i].split('.').length > 1) {
                if (e.detail.value[i].split('.')[1].length == 1) {
                } else {
                  percent_check.push(e.detail.value[i])
                }
              } else { }
            }
          }
        }
      }
      if (selected_index.length == 0) {
        wx.showToast({
          title: '请输入合伙人对应的比例！',
          icon: 'none'
        })
      } else {
        if (selected_index.toString() != ids_index.toString()) {
          wx.showToast({
            title: '请输入合伙人对应的比例！',
            icon: 'none'
          })
        } else {
          if (percent_check.length == 0) {
            that.setData({
              loading_layer_status: 'show'
            })
            var percent_deal = []
            for (var i = 0; i < percent.length; i++) {
              percent_deal.push((Number(percent[i]) * 100).toFixed(2).split('.')[0])
            }
            var sendData = {
              deviceId: that.data.device_id,
              userIds: ids_arr.toString(),
              proportions: percent_deal.toString(),
            }
            server.postData(sendData, '/devices/addPartners', function (res) {
              // console.log(res)
              that.setData({
                loading_layer_status: 'hidden'
              })
              if (res.code == 200) {
                wx.showToast({
                  title: '绑定合伙人成功',
                  icon: 'none'
                })
                setTimeout(function () {
                  wx.navigateBack({
                    delta: 1
                  })
                }, 1500)
              } else {
                wx.showToast({
                  title: res.message,
                  icon: 'none'
                })
              }
            })
          } else {
            wx.showToast({
              title: '合伙人对应的比例必须是0-100之间的数，且比例最多只能输入一位小数！！',
              icon: 'none'
            })
          }
        }
      }
    } else {
      wx.showToast({
        title: '请选择合伙人！',
        icon: 'none'
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})