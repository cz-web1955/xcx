// pages/index/home/equipManage/equipDetail/equipUpdate/equipUpdate.js
var app = getApp();
// 引入request.js
var server = require('../../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '修改信息', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    equip_infor: '',
    // equip_num: '',
    // equip_type: [],
    // equip_type_show: [],
    // type_index: 0,
    // area_list: [],
    // area_list_show: [],
    // area_index: 0,
    property_list: [],
    property_list_show: [],
    property_index: 0,
    property_status: true,
    loading_layer_status: 'hidden',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // that.setData({
    //   equip_infor: options,
    // })
    // 获取设备信息
    that.getEquipInfor(options.id)
  },

  // 获取设备信息
  getEquipInfor: function (id) {
    var that = this;
    server.getData('', '/devices/getByDeviceId/' + id, function (res) {
      console.log(res)
      if (res.code == 200) {
        if (res.data.propertyId == null || res.data.propertyId == '') {
          that.data.property_status = false
        } else {
          that.data.property_status = true
        }
        that.setData({
          equip_infor: res.data,
          property_status: that.data.property_status
          // equip_num: res.data.deviceId
        })
        // // 获取设备类型数据
        // that.getEquipType()
        // // 获取区域列表数据
        // that.getArea()
        // 获取物业公司列表数据
        that.getProperty()
      }
    })
  },

  // // 点击扫码
  // scanCode: function () {
  //   var that = this;
  //   wx.scanCode({
  //     success: function (res) {
  //       // console.log(res)
  //       that.setData({
  //         equip_num: res.result
  //       })
  //     }
  //   })
  // },

  // // 获取设备类型数据
  // getEquipType: function () {
  //   var that = this;
  //   server.getData('', '/dicts?type=devType', function (res) {
  //     // console.log(res)
  //     for (var i = 0; i < res.length; i++) {
  //       that.data.equip_type_show.push(res[i].val)
  //       if (res[i].k == that.data.equip_infor.deviceType) {
  //         that.data.type_index = i
  //       }
  //     }
  //     that.setData({
  //       equip_type_show: that.data.equip_type_show,
  //       equip_type: res,
  //       type_index: that.data.type_index
  //     })
  //   })
  // },

  // // 监听设备类型
  // bindTypeChange: function (e) {
  //   var that = this;
  //   that.setData({
  //     type_index: e.detail.value
  //   })
  // },

  // // 获取区域列表数据
  // getArea: function () {
  //   var that = this;
  //   var sendData = {
  //     page: 1,
  //     limit: '10000'
  //   }
  //   server.postData(sendData, '/areas/findList', function (res) {
  //     // console.log(res)
  //     if (res.code == 200) {
  //       for (var i = 0; i < res.data.length; i++) {
  //         that.data.area_list_show.push(res.data[i].name)
  //         if (res.data[i].id == that.data.equip_infor.areaId) {
  //           that.data.area_index = i
  //         }
  //       }
  //       that.setData({
  //         area_list_show: that.data.area_list_show,
  //         area_list: res.data,
  //         area_index: that.data.area_index
  //       })
  //     }
  //   })
  // },

  // // 监听区域
  // bindAreaChange: function (e) {
  //   var that = this;
  //   that.setData({
  //     area_index: e.detail.value
  //   })
  // },

  // 获取物业公司列表数据
  getProperty: function () {
    var that = this;
    var sendData = {
      roleId: '4',
      page: 1,
      limit: '10000'
    }
    server.postData(sendData, '/users/findList', function (res) {
      // console.log(res)
      if (res.code == 200) {
        res.data.unshift({ id: '', nickname: '请选择物业公司' })
        for (var i = 0; i < res.data.length; i++) {
          that.data.property_list_show.push(res.data[i].nickname)
          if (res.data[i].id == that.data.equip_infor.propertyId) {
            that.data.property_index = i
          }
        }
        that.setData({
          property_list_show: that.data.property_list_show,
          property_list: res.data,
          property_index: that.data.property_index
        })
      }
    })
  },

  // 监听物业公司
  bindPropertyChange: function (e) {
    var that = this;
    that.setData({
      property_index: e.detail.value
    })
  },

  // 点击保存按钮
  updateSubmit: function (e) {
    var that = this;
    if (e.detail.value.equipName == '') {
      wx.showToast({
        title: '请输入设备名称！',
        icon: 'none'
      })
    } else if (e.detail.value.address == '') {
      wx.showToast({
        title: '请输入地址！',
        icon: 'none'
      })
    } else {
      that.setData({
        loading_layer_status: 'show'
      })
      var sendData = {
        id: that.data.equip_infor.id,
        deviceName: e.detail.value.equipName,
        address: e.detail.value.address,
        propertyId: that.data.property_list[that.data.property_index].id,
      }
      server.postFData(sendData, '/devices/updatedeviceName', function (res) {
        // console.log(res)
        that.setData({
          loading_layer_status: 'hidden'
        })
        if (res.code == 200) {
          wx.showToast({
            title: '修改成功！',
            icon: 'none'
          })
          setTimeout(function () {
            wx.navigateBack({
              delta: 1
            })
          }, 1500)
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})