// pages/index/home/equipManage/equipDetail/equipDetail.js
var app = getApp();
// 引入request.js
var server = require('../../../../../utils/request.js')
// 引入util.js
var util = require('../../../../../utils/util.js')
var dateTimePicker = require('../../../../../utils/dateTimePicker.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '设备详情', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,
    menu_status: [true, false, false, false],
    equip_id: '',
    equip_infor: '',
    loading_layer_status: 'show',
    judge_page_status: false,
    old_tem_show: [],
    old_tem: [],
    old_index: 0,
    water_tem_show: [],
    water_tem: [],
    tem_index: 0,
    end_time: '',
    month_price: '',
    startYear: 2010,
    endYear: 2030,
    water_loop_infor: { power: '', time: '' },
    water_loop: ['1', '2', '3', '4', '5'],
    loop_index: 0,
    expend_infor: '',
    // coin_model: ['0', '1', '2', '3'],
    coin_model: ['停用', '5毛', '1元', 'RS232'],
    coin_index: 0,
    work_status: '',
    wash_model: ['不冲洗', '开机冲洗', '关机冲洗', '开关机冲洗'],
    model_index: 0,
    month_consum: '',
    on_off_check: 0,
    logic_check: 0,
    light_check: 0,
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.equip_id = options.id
    // 获取设备信息
    that.getEquipInfor()
  },

  // 获取设备信息
  getEquipInfor: function () {
    var that = this;
    server.getData('', '/devices/getByDeviceId/' + that.data.equip_id, function (res) {
      console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.deviceType == '1') {
          // 获取水价模板
          that.getWaterTem(res.data.tplId)
         
        }
        var obj = dateTimePicker.dateTimePicker(that.data.startYear, that.data.endYear);
        if (res.data.endTime != null) {
          var year_index;
          for (var i = 0; i < obj.dateTimeArray[0].length; i++) {
            if (obj.dateTimeArray[0][i] == res.data.endTime.split(' ')[0].split('-')[0]) {
              year_index = i;
            }
          }
          obj.dateTime[0] = Number(year_index)
          obj.dateTime[1] = Number(res.data.endTime.split(' ')[0].split('-')[1]) - 1
          obj.dateTime[2] = Number(res.data.endTime.split(' ')[0].split('-')[2]) - 1
          obj.dateTime[3] = Number(res.data.endTime.split(' ')[1].split(':')[0])
          obj.dateTime[4] = Number(res.data.endTime.split(' ')[1].split(':')[1])
          obj.dateTime[5] = Number(res.data.endTime.split(' ')[1].split(':')[2])
          that.setData({
            dateTime: obj.dateTime,
            dateTimeArray: obj.dateTimeArray,
            end_time: res.data.endTime
          });
        } else {
          that.setData({
            dateTime: obj.dateTime,
            dateTimeArray: obj.dateTimeArray,
            end_time: util.formatYTime(new Date())
          });
        }
        if (res.data.monthPrice != null) {
          that.data.month_price = res.data.monthPrice
        } else {
          that.data.month_price = ''
        }
        that.setData({
          equip_infor: res.data,
          month_price: that.data.month_price
        })
        // 获取出水设置
        that.getFlowSet('1')
        // 获取旧卡模板
        that.getOldTem()
        // 获取消费额设置数据
        that.getExpend()
        // 获取滤芯设置数据
        that.getFilterSet()
        // 获取当月消费情况数据
        that.getMonth()
      }
    })
  },

  // 点击箭头
  pullMenu: function (e) {
    var that = this;
    if (that.data.menu_status[Number(e.currentTarget.dataset.index)]) {
      return
    } else {
      for (var i = 0; i < that.data.menu_status.length; i++) {
        if (i == Number(e.currentTarget.dataset.index)) {
          that.data.menu_status[i] = true
        } else {
          that.data.menu_status[i] = false
        }
      }
      that.setData({
        menu_status: that.data.menu_status
      })
    }
  },

  // 获取水价模板
  getWaterTem: function (tplId) {
    var that = this;
    var sendData = {
      page: 1,
      limit: '1000'
    }
    server.postData(sendData, '/waterPrice/findList', function (res) {
      // console.log(res)
      if (res.code == 200) {
        for (var i = 0; i < res.data.length; i++) {
          that.data.water_tem_show.push(res.data[i].modelname)
          if(res.data[i].id == tplId){
            that.setData({
              tem_index: i
            })
          }
        }
        that.setData({
          water_tem_show: that.data.water_tem_show,
          water_tem: res.data
        })
        
      }
    })
  },

  // 监听水价模板选择
  bindTemChange: function (e) {
    var that = this;
    that.setData({
      tem_index: e.detail.value
    })
  },

  // 监听日期变化
  changeDateTime(e) {
    var that = this;
    that.data.end_time = that.data.dateTimeArray[0][e.detail.value[0]] + '-' + that.data.dateTimeArray[1][e.detail.value[1]] + '-' + that.data.dateTimeArray[2][e.detail.value[2]] + ' ' + that.data.dateTimeArray[3][e.detail.value[3]] + ':' + that.data.dateTimeArray[4][e.detail.value[4]] + ':' + that.data.dateTimeArray[5][e.detail.value[5]]
    that.setData({
      dateTime: e.detail.value,
    });
  },

  // 点击计费方式启用按钮
  accountSubmit: function (e) {
    var that = this;
    if (that.data.equip_infor.deviceType == '1') {
      // 流量计费
      if (that.data.equip_infor.status != '离线') {
        if (that.data.water_tem.length == 0) {
          wx.showToast({
            title: '请先添加水价模板！',
            icon: 'none'
          })
        } else {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            deviceId: that.data.equip_infor.deviceId,
            modelId: that.data.water_tem[that.data.tem_index].id,
          }
          server.postData(sendData, '/devices/setPrice', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '设置成功！',
                icon: 'none'
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      } else {
        wx.showToast({
          title: '该设备离线，设置无效！',
          icon: 'none'
        })
      }
    } else if (that.data.equip_infor.deviceType == '2') {
      // 时间计费
      if (that.data.equip_infor.status != '离线') {
        if (e.detail.value.price == '') {
          wx.showToast({
            title: '请输入月租价格！',
            icon: 'none'
          })
        } else {
          that.setData({
            loading_layer_status: 'show'
          })
          var sendData = {
            id: that.data.equip_infor.id,
            endTime: that.data.end_time,
            monthPrice: e.detail.value.price,
          }
          server.postFData(sendData, '/devices/updatedevice', function (res) {
            // console.log(res)
            that.setData({
              loading_layer_status: 'hidden'
            })
            if (res.code == 200) {
              wx.showToast({
                title: '设置成功！',
                icon: 'none'
              })
            } else {
              wx.showToast({
                title: res.message,
                icon: 'none'
              })
            }
          })
        }
      } else {
        wx.showToast({
          title: '该设备离线，设置无效！',
          icon: 'none'
        })
      }
    }
  },

  // 获取旧卡模板
  getOldTem: function () {
    var that = this;
    var sendData = {
      page: 1,
      limit: '1000000'
    }
    server.postData(sendData, '/oldcardSigns/findList', function (res) {
      // console.log(res)
      if (res.code == 200) {
        for (var i = 0; i < res.data.length; i++) {
          that.data.old_tem_show.push(res.data[i].tplname)
        }
        that.setData({
          old_tem_show: that.data.old_tem_show,
          old_tem: res.data
        })
      }
    })
  },

  // 监听旧卡模板选择
  bindOldChange: function (e) {
    var that = this;
    that.setData({
      old_index: e.detail.value
    })
  },

  // 点击设置旧卡启用按钮
  setOldCard: function (e) {
    var that = this;
    if (that.data.equip_infor.status != '离线') {
      that.setData({
        loading_layer_status: 'show'
      })
      var sendData = {
        deviceId: that.data.equip_infor.deviceId,
        tplId: that.data.old_tem[e.detail.value.oldTem].id
      }
      server.postData(sendData, '/devices/setCard', function (res) {
        // console.log(res)
        that.setData({
          loading_layer_status: 'hidden'
        })
        if (res.code == 200) {
          wx.showToast({
            title: '设置成功！',
            icon: 'none'
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    } else {
      wx.showToast({
        title: '该设备离线，设置无效！',
        icon: 'none'
      })
    }
  },

  // 获取出水设置
  getFlowSet: function (no) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      deviceId: that.data.equip_infor.deviceId,
      no: no,
    }
    server.postData(sendData, '/devices/findPower', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        that.data.water_loop_infor.power = res.data.power
        that.data.water_loop_infor.time = res.data.time
        that.setData({
          water_loop_infor: that.data.water_loop_infor
        })
      } else {
        that.data.water_loop_infor.power = ''
        that.data.water_loop_infor.time = ''
        that.setData({
          water_loop_infor: that.data.water_loop_infor
        })
        wx.showToast({
          title: res.message,
          icon: 'none'
        })
      }
    })
  },

  // 监听水路选择
  bindLoopChange: function (e) {
    var that = this;
    that.setData({
      loop_index: e.detail.value
    })
    var no = Number(e.detail.value) + 1
    // 获取出水设置
    that.getFlowSet(no)
  },

  // 点击出水设置启用按钮
  flowSetSubmit: function (e) {
    var that = this;
    if (that.data.equip_infor.status != '离线') {
      if (e.detail.value.pulse == '') {
        wx.showToast({
          title: '请输入脉冲数！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.pulse) < 20 || Number(e.detail.value.pulse) > 1000) {
        wx.showToast({
          title: '脉冲数只能是20～1000之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.time == '') {
        wx.showToast({
          title: '请输入出水时间！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.time) < 15 || Number(e.detail.value.time) > 500) {
        wx.showToast({
          title: '出水时间只能是15～500之间的数！',
          icon: 'none'
        })
      } else {
        that.setData({
          loading_layer_status: 'show'
        })
        var sendData = {
          deviceId: that.data.equip_infor.deviceId,
          no: (Number(e.detail.value.loop) + 1),
          power: e.detail.value.pulse,
          time: e.detail.value.time,
        }
        server.postData(sendData, '/devices/setPower', function (res) {
          // console.log(res)
          that.setData({
            loading_layer_status: 'hidden'
          })
          if (res.code == 200) {
            wx.showToast({
              title: '设置成功！',
              icon: 'none'
            })
          } else {
            wx.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
      }
    } else {
      wx.showToast({
        title: '该设备离线，设置无效！',
        icon: 'none'
      })
    }
  },

  // 获取消费额设置数据
  getExpend: function () {
    var that = this;
    var sendData = {
      deviceId: that.data.equip_infor.deviceId,
    }
    server.postData(sendData, '/devices/findSet', function (res) {
      console.log(res)
      if (res.code == 200) {
        if (Number(res.data.cxms) > 3 || Number(res.data.cxms) < 0) {
          that.data.model_index = 0
        } else {
          that.data.model_index = Number(res.data.cxms)
        }
        if (Number(res.data.dykgsx) < 0 || Number(res.data.dykgsx) > 1) {
          that.data.on_off_check = 0;
        } else {
          that.data.on_off_check = Number(res.data.dykgsx);
        }
        if (Number(res.data.ljgx) < 0 || Number(res.data.ljgx) > 1) {
          that.data.logic_check = 0;
        } else {
          that.data.logic_check = Number(res.data.ljgx);
        }
        if (Number(res.data.ggdkzms) < 0 || Number(res.data.ggdkzms) > 1) {
          that.data.light_check = 0;
        } else {
          that.data.light_check = Number(res.data.ggdkzms)
        }
        that.setData({
          expend_infor: res.data,
          coin_index: res.data.tbqms,
          model_index: that.data.model_index,
          on_off_check: that.data.on_off_check,
          logic_check: that.data.logic_check,
          light_check: that.data.light_check
        })
      }
    })
  },

  // 监听投币器模式
  bindCoinChange: function (e) {
    var that = this;
    that.setData({
      coin_index: e.detail.value
    })
  },

  // 点击消费额设置启用按钮
  expendSubmit: function (e) {
    var that = this;
    if (that.data.equip_infor.status != '离线') {
      if (e.detail.value.onceFee == '') {
        wx.showToast({
          title: '请输入最大单次消费额！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.onceFee) < 5 || Number(e.detail.value.onceFee) > 100) {
        wx.showToast({
          title: '最大单次消费额只能是5～100之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.onceTime == '') {
        wx.showToast({
          title: '请输入单次消费最长时间！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.onceTime) < 5 || Number(e.detail.value.onceTime) > 100) {
        wx.showToast({
          title: '单次消费最长时间只能是5～100之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.percent == '') {
        wx.showToast({
          title: '请输入投币出水百分比！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.percent) < 1 || Number(e.detail.value.percent) > 100) {
        wx.showToast({
          title: '投币出水百分比只能是1～100之间的数！',
          icon: 'none'
        })
      } else {
        that.setData({
          loading_layer_status: 'show'
        })
        var cmd = e.detail.value.onceFee + ',' + e.detail.value.onceTime + ',' + e.detail.value.coinModel + ',' + e.detail.value.percent
        var sendData = {
          cmd: cmd,
          deviceId: that.data.equip_infor.deviceId
        }
        server.postData(sendData, '/devices/setAmount', function (res) {
          // console.log(res)
          that.setData({
            loading_layer_status: 'hidden'
          })
          if (res.code == 200) {
            wx.showToast({
              title: '设置成功！',
              icon: 'none'
            })
          } else {
            wx.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
      }
    } else {
      wx.showToast({
        title: '该设备离线，设置无效！',
        icon: 'none'
      })
    }
  },

  // 点击开关控制启用按钮
  switchConSubmit: function (e) {
    var that = this;
    if (that.data.equip_infor.status != '离线') {
      that.setData({
        loading_layer_status: 'show'
      })
      var sendData = {
        deviceId: that.data.equip_infor.deviceId,
        key: e.detail.value.onOff
      }
      server.postData(sendData, '/devices/reset', function (res) {
        // console.log(res)
        that.setData({
          loading_layer_status: 'hidden'
        })
        if (res.code == 200) {
          wx.showToast({
            title: '设置成功！',
            icon: 'none'
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    } else {
      wx.showToast({
        title: '该设备离线，设置无效！',
        icon: 'none'
      })
    }
  },

  // // 探头设置
  // probeSetSubmit: function (e) {
  //   var that = this;
  //   console.log(e)
  // },

  // 获取滤芯设置数据
  getFilterSet: function () {
    var that = this;
    var sendData = {
      deviceId: that.data.equip_infor.deviceId
    }
    server.postData(sendData, '/devices/searchStatus', function (res) {
      // console.log(res)
      if (res.code == 200) {
        that.setData({
          work_status: res.data
        })
      }
    })
  },

  // 点击滤芯重置按钮
  resetFilter: function (e) {
    var that = this;
    if (that.data.equip_infor.status != '离线') {
      that.setData({
        loading_layer_status: 'show'
      })
      var sendData = {
        deviceId: that.data.equip_infor.deviceId,
        key: e.currentTarget.dataset.val
      }
      server.postData(sendData, '/devices/clearZero', function (res) {
        // console.log(res)
        that.setData({
          loading_layer_status: 'hidden'
        })
        if (res.code == 200) {
          wx.showToast({
            title: '重置成功！',
            icon: 'none'
          })
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none'
          })
        }
      })
    } else {
      wx.showToast({
        title: '该设备离线，设置无效！',
        icon: 'none'
      })
    }
  },

  // 获取当月消费情况数据
  getMonth: function () {
    var that = this;
    var sendData = {
      deviceId: that.data.equip_infor.deviceId
    }
    server.postData(sendData, '/devices/findMonth', function (res) {
      // console.log(res)
      if (res.code == 200) {
        that.setData({
          month_consum: res.data
        })
      }
    })
  },

  // 监听冲洗模式
  bindWashChange: function (e) {
    var that = this;
    that.setData({
      model_index: e.detail.value
    })
  },

  // 点击制水参数启用按钮
  waterParamsSubmit: function (e) {
    var that = this;
    if (that.data.equip_infor.status != '离线') {
      if (e.detail.value.washTime == '') {
        wx.showToast({
          title: '请输入冲洗时间！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.washTime) < 5 || Number(e.detail.value.washTime) > 60) {
        wx.showToast({
          title: '冲洗时间只能是5～60之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.washInterval == '') {
        wx.showToast({
          title: '请输入冲洗间隔！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.washInterval) < 5 || Number(e.detail.value.washInterval) > 255) {
        wx.showToast({
          title: '冲洗间隔只能是5～255之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.waterMM == '') {
        wx.showToast({
          title: '请输入制水延时分钟数！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.waterMM) < 0 || Number(e.detail.value.waterMM) > 30) {
        wx.showToast({
          title: '制水延时分钟只能是0～30之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.waterMS == '') {
        wx.showToast({
          title: '请输入制水延时秒数！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.waterMS) < 0 || Number(e.detail.value.waterMS) > 60) {
        wx.showToast({
          title: '制水延时秒数只能是0～60之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.waterFS == '') {
        wx.showToast({
          title: '请输入满水延时！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.waterFS) < 5 || Number(e.detail.value.waterFS) > 60) {
        wx.showToast({
          title: '满水延时只能是5～60之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.steriTime == '') {
        wx.showToast({
          title: '请输入杀菌时间！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.steriTime) < 5 || Number(e.detail.value.steriTime) > 60) {
        wx.showToast({
          title: '杀菌时间只能是5～60之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.steriInterH == '') {
        wx.showToast({
          title: '请输入杀菌间隔时间！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.steriInterH) < 0 || Number(e.detail.value.steriInterH) > 23) {
        wx.showToast({
          title: '杀菌间隔时间只能是0～23之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.steriInterM == '') {
        wx.showToast({
          title: '请输入杀菌间隔分钟！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.steriInterH) < 0 || Number(e.detail.value.steriInterH) > 60) {
        wx.showToast({
          title: '杀菌间隔分钟只能是0～60之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.accountTime == '') {
        wx.showToast({
          title: '请输入显示结算延时时间！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.accountTime) < 3 || Number(e.detail.value.accountTime) > 60) {
        wx.showToast({
          title: '显示结算延时时间只能是3～60之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.closeDelay == '') {
        wx.showToast({
          title: '请输入打水灯关闭延时时间！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.closeDelay) < 5 || Number(e.detail.value.closeDelay) > 60) {
        wx.showToast({
          title: '打水灯关闭延时时间只能是5～60之间的数！',
          icon: 'none'
        })
      } else {
        that.setData({
          loading_layer_status: 'show'
        })
        var cmd = e.detail.value.washTime + ',' + e.detail.value.washInterval + ',' + e.detail.value.washModel + ',' + e.detail.value.waterMM + ',' + e.detail.value.waterMS + ',' + e.detail.value.waterFS + ',' + e.detail.value.steriTime + ',' + e.detail.value.steriInterH + ',' + e.detail.value.steriInterM + ',' + e.detail.value.accountTime + ',' + e.detail.value.closeDelay + ',' + e.detail.value.onOff + ',' + e.detail.value.logic
        var sendData = {
          cmd: cmd,
          deviceId: that.data.equip_infor.deviceId
        }
        server.postData(sendData, '/devices/setMakeWater', function (res) {
          // console.log(res)
          that.setData({
            loading_layer_status: 'hidden'
          })
          if (res.code == 200) {
            wx.showToast({
              title: '操作成功！',
              icon: 'none'
            })
          } else {
            wx.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
      }
    } else {
      wx.showToast({
        title: '该设备离线，设置无效！',
        icon: 'none'
      })
    }
  },

  // 点击照明温度参数启用按钮
  lightParamsSubmit: function (e) {
    var that = this;
    if (that.data.equip_infor.status != '离线') {
      if (e.detail.value.adsSH == '') {
        wx.showToast({
          title: '请输入广告灯开启时间！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.adsSH) < 0 || Number(e.detail.value.adsSH) > 23) {
        wx.showToast({
          title: '广告灯开启时间只能是0～23之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.adsSM == '') {
        wx.showToast({
          title: '请输入广告灯开启分钟！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.adsSM) < 0 || Number(e.detail.value.adsSM) > 59) {
        wx.showToast({
          title: '广告灯开启分钟只能是0～59之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.adsCH == '') {
        wx.showToast({
          title: '请输入广告灯关闭时间！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.adsCH) < 0 || Number(e.detail.value.adsCH) > 23) {
        wx.showToast({
          title: '广告灯关闭时间只能是0～23之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.adsCM == '') {
        wx.showToast({
          title: '请输入广告灯关闭分钟！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.adsCM) < 0 || Number(e.detail.value.adsCM) > 59) {
        wx.showToast({
          title: '广告灯关闭分钟只能是0～59之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.temFirstUT == '') {
        wx.showToast({
          title: '请输入温控1启动温度！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.temFirstUT) < 1 || Number(e.detail.value.temFirstUT) > 30) {
        wx.showToast({
          title: '温控1启动温度只能是1～30之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.temFirstST == '') {
        wx.showToast({
          title: '请输入温控1停止温度！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.temFirstST) < 1 || Number(e.detail.value.temFirstST) > 30) {
        wx.showToast({
          title: '温控1停止温度只能是1～30之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.temSecondUT == '') {
        wx.showToast({
          title: '请输入温控2启动温度！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.temSecondUT) < 1 || Number(e.detail.value.temSecondUT) > 30) {
        wx.showToast({
          title: '温控2启动温度只能是1～30之间的数！',
          icon: 'none'
        })
      } else if (e.detail.value.temSecondST == '') {
        wx.showToast({
          title: '请输入温控2停止温度！',
          icon: 'none'
        })
      } else if (Number(e.detail.value.temSecondST) < 1 || Number(e.detail.value.temSecondST) > 30) {
        wx.showToast({
          title: '温控2停止温度只能是1～30之间的数！',
          icon: 'none'
        })
      } else {
        that.setData({
          loading_layer_status: 'show'
        })
        var cmd = e.detail.value.lightModel + ',' + e.detail.value.adsSH + ',' + e.detail.value.adsSM + ',' + e.detail.value.adsCH + ',' + e.detail.value.adsCM + ',' + e.detail.value.temFirstUT + ',' + e.detail.value.temFirstST + ',' + e.detail.value.temSecondUT + ',' + e.detail.value.temSecondST
        var sendData = {
          cmd: cmd,
          deviceId: that.data.equip_infor.deviceId
        }
        server.postData(sendData, '/devices/setLight', function (res) {
          // console.log(res)
          that.setData({
            loading_layer_status: 'hidden'
          })
          if (res.code == 200) {
            wx.showToast({
              title: '操作成功！',
              icon: 'none'
            })
          } else {
            wx.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        })
      }
    } else {
      wx.showToast({
        title: '该设备离线，设置无效！',
        icon: 'none'
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_status) {
      // 获取设备信息
      that.getEquipInfor()
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_status = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})