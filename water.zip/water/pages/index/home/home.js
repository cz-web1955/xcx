// pages/index/home/home.js
import * as echarts from '../../../ec-canvas/echarts';
var app = getApp();
// 引入request.js
var server = require('../../../utils/request.js')
// 引入util.js
var util = require('../../../utils/util.js')

var chart1;
var chart2;
function initChart1(online, offline) {
  return {
    backgroundColor: "#ffffff",
    color: ["#b9eac2", "#ff7869"],
    series: [{
      label: {
        normal: {
          fontSize: 12
        }
      },
      type: 'pie',
      center: ['50%', '45%'],
      radius: [0, '60%'],
      data: [{
        value: online,
        name: '在线'
      }, {
        value: offline,
        name: '离线'
      }],
      itemStyle: {
        emphasis: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 2, 2, 0.3)'
        }
      }
    }]
  }
}

function initChart2(bind, unbind, blackm) {
  return {
    backgroundColor: "#ffffff",
    color: ["#b9eac2", "#009944", "#ff7869"],
    series: [{
      label: {
        normal: {
          fontSize: 10
        }
      },
      type: 'pie',
      center: ['50%', '45%'],
      radius: [0, '60%'],
      data: [{
        value: bind,
        name: '绑卡会员'
      }, {
        value: unbind,
        name: '未绑卡会员'
      }, {
        value: blackm,
        name: '黑名单'
      }],
      itemStyle: {
        emphasis: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 2, 2, 0.3)'
        }
      }
    }]
  }
}

Page({

  // 页面的初始数据
  data: {
    ec1: {
      onInit: function (canvas, width, height) {
        chart1 = echarts.init(canvas, null, { width: width, height: height });
        canvas.setChart(chart1);
        chart1.setOption(initChart1(0, 0));
        return chart1;
      }
    },
    ec2: {
      onInit: function (canvas, width, height) {
        chart2 = echarts.init(canvas, null, { width: width, height: height });
        canvas.setChart(chart2);
        chart2.setOption(initChart2(0, 0, 0));
        return chart2;
      }
    },
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '首页', backStatus: false },
    top_height: '',
    top_height1: '',
    window_height: app.globalData.windowHeight,
    statis_infor: { sumerAllMoenyDeal: 0, sumerMoenyDeal: 0, payAllMoneyDeal: 0, saleMoneyDeal: 0, sumerAllVolDeal: 0, sumerDayVolDeal: 0, coinSumDeal: 0, coinCountSumDeal: 0, codeSumDeal: 0, codeCountSumDeal: 0, cardSumDeal: 0, cardCountSumDeal: 0 },
    equip_infor: { online: 0, offline: 0, total: 0 },
    member_infor: '',
    banner_list: [],
    menu_list: [],
    bottom_nav: [],
    loading_layer_status: 'hidden',
    judge_page_status: false,

    parpro_infor: '',
    time_cate: ['今日', '本月'],
    time_index: 0,
    equip_arr_show: [],
    equip_arr: [],
    equip_index: 0,
    current_page: 1,
    total_page: '',
    recharge_list_status: true,
    recharge_list: [],

    share_cate: '',
    pro_statis: '',
    rent_current_page: 1,
    rent_total_page: '',
    equip_rent_status: true,
    equip_rent: [],

    agent_status: ''
  },

  // 生命周期函数--监听页面加载
  onLoad: function (options) {
    var that = this;
    if (wx.getStorageSync('token') == '') {
      wx.reLaunch({
        url: '/pages/login/startPage/startPage',
      })
      return false
    }
    // 获取用户信息
    that.getUserInfor()
  },

  // 获取用户信息
  getUserInfor: function () {
    var that = this;
    if (wx.getStorageSync('user') == '') {
      server.getData('', '/users/current', function (res) {
        // console.log(res)
        wx.setStorageSync('user', res)
        that.setData({
          agent_status: wx.getStorageSync('user').agent_status
        })
        // 根据角色不同显示不同的信息
        that.roleInfor()
      })
    } else {
      var id = wx.getStorageSync('user').id
      server.getData('', '/users/current/' + id, function (res) {
        // console.log(res)
        if (res.code == 200) {
          var user = res.data
          wx.setStorageSync('user', user)
          that.setData({
            agent_status: wx.getStorageSync('user').agent_status
          })
          // 根据角色不同显示不同的信息
          that.roleInfor()
        }
      })
    }
  },

  // 根据角色不同显示不同的信息
  roleInfor: function () {
    var that = this;
    if (that.data.agent_status == 1) {
      // 代理商展示信息
      var menu_list = [
        { title: '设备管理', iconUrl: 'https://api.010ozner.com/image/home_01.png', pathUrl: '/pages/index/home/equipManage/equipManage' },
        { title: '代客开卡', iconUrl: 'https://api.010ozner.com/image/home_02.png', pathUrl: '/pages/index/home/activateCard/activateCard' },
        { title: '水卡充值', iconUrl: 'https://api.010ozner.com/image/home_03.png', pathUrl: '/pages/index/home/rechargeCard/rechargeCard?cardid=' + '' },
        { title: '充值记录', iconUrl: 'https://api.010ozner.com/image/home_04.png', pathUrl: '/pages/index/home/rechargeRecord/rechargeRecord?deviceid=' + '' + '&wxid=' + '' + '&cardid=' + '' },
        { title: '消费记录', iconUrl: 'https://api.010ozner.com/image/home_05.png', pathUrl: '/pages/index/home/consumeRecord/consumeRecord?wxid=' + '' },
        { title: '水卡管理', iconUrl: 'https://api.010ozner.com/image/home_06.png', pathUrl: '/pages/index/home/cardManage/cardManage' },
        { title: '促销员管理', iconUrl: 'https://api.010ozner.com/image/home_07.png', pathUrl: '/pages/index/home/saleManage/saleManage' },
        { title: '用户管理', iconUrl: 'https://api.010ozner.com/image/home_10.png', pathUrl: '/pages/index/home/fans/fans' },
      ]
      var bottom_nav = [
        { title: '首页', iconUrl: 'https://api.010ozner.com/image/11.png', selected: true, pathUrl: '' },
        { title: '统计', iconUrl: 'https://api.010ozner.com/image/2.png', selected: false, pathUrl: '/pages/index/statis/statis' },
        { title: '我的', iconUrl: 'https://api.010ozner.com/image/3.png', selected: false, pathUrl: '/pages/index/mine/mine' }
      ]
      that.setData({
        menu_list: menu_list,
        bottom_nav: bottom_nav
      })
      // 获取统计信息
      that.getStatisInfor()
      // 获取饼图1数据
      that.getPie1()
      // 获取饼图2数据
      that.getPie2()
    } else if (that.data.agent_status == 2) {
      // 促销员
      var menu_list = [
        { title: '开卡记录', iconUrl: 'https://api.010ozner.com/image/home_06.png', pathUrl: '/pages/index/home/openCardRS/openCardRS' },
        { title: '代客开卡', iconUrl: 'https://api.010ozner.com/image/home_02.png', pathUrl: '/pages/index/home/activateCard/activateCard' },
        { title: '水卡充值', iconUrl: 'https://api.010ozner.com/image/home_03.png', pathUrl: '/pages/index/home/rechargeCard/rechargeCard?cardid=' + '' },
        { title: '充值记录', iconUrl: 'https://api.010ozner.com/image/home_04.png', pathUrl: '/pages/index/home/rechargeRecord/rechargeRecord?deviceid=' + '' + '&wxid=' + '' + '&cardid=' + '' },
      ]
      var bottom_nav = [
        { title: '首页', iconUrl: 'https://api.010ozner.com/image/11.png', selected: true, pathUrl: '' },
        { title: '我的', iconUrl: 'https://api.010ozner.com/image/3.png', selected: false, pathUrl: '/pages/index/mine/mine' }
      ]
      that.setData({
        menu_list: menu_list,
        bottom_nav: bottom_nav
      })
      // 获取合伙人、物业公司数据
      that.getParPro()
      // 获取促销员开卡/充值记录
      that.getOpenRecharge(1, '10')
    } else if (that.data.agent_status == 3) {
      // 合伙人、物业公司
      var bottom_nav = [
        { title: '首页', iconUrl: 'https://api.010ozner.com/image/11.png', selected: true, pathUrl: '' },
        { title: '我的', iconUrl: 'https://api.010ozner.com/image/3.png', selected: false, pathUrl: '/pages/index/mine/mine' }
      ]
      that.setData({
        bottom_nav: bottom_nav
      })
      if (wx.getStorageSync('user').rent != null) {
        // 租金模式
        that.setData({
          share_cate: '2'
        })
        // 获取合伙人、物业公司统计情况
        that.getProStatis()
        // 获取设备租金列表
        that.getEquipRent(1, '10')
        util.getRect('scroll-area1', function (res) {
          that.setData({
            top_height1: res + 80
          })
        })
      } else {
        // 提成比例
        that.setData({
          share_cate: '1'
        })
        // 获取合伙人、物业公司数据
        that.getParPro()
        // 获取设备列表
        that.getEquipList()
        // 获取充值记录列表
        that.getRechargeRecord('', 'day', 1, '10')
        util.getRect('scroll-area1', function (res) {
          that.setData({
            top_height1: res + 50
          })
        })
      }
    }
    // 获取轮播图列表
    that.getBanner()
  },

  // 获取轮播图列表
  getBanner: function () {
    var that = this;
    var sendData = {
      sTime: "",
      eTime: "",
      page: 1,
      limit: 5
    }
    server.postData(sendData, '/userImages/findList', function (res) {
      // console.log(res)
      if (res.code == 200) {
        if(res.data.length != 0){
          that.data.banner_list = []
          for(var i = 0; i < res.data.length; i++){
            that.data.banner_list.push('https://api.010ozner.com' + res.data[i].imgUrl)
          }
          that.setData({
            banner_list: that.data.banner_list
          })
        } else {
          that.data.banner_list = []
          that.data.banner_list.push('https://api.010ozner.com/image/banner.png')
          that.setData({
            banner_list: that.data.banner_list
          })
        }
      }
    })
  },

  // 获取饼图1数据
  getPie1: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    server.getData('', '/count/deviceStatus', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        var online=0;
        var offline=0;
        for (var i = 0; i < res.data.length; i++) {
          if (res.data[i].status == '在线') {
            online = res.data[i].counts
          } else if (res.data[i].status == '离线') {
            offline = res.data[i].counts
          }
        }
        that.data.equip_infor.online = online;
        that.data.equip_infor.offline = offline;
        that.data.equip_infor.total = online + offline;
        that.setData({
          equip_infor: that.data.equip_infor
        })
        setTimeout(function () {
          chart1.setOption(initChart1(online, offline));
        }, 500)
      }
    })
  },

  // 获取饼图2数据
  getPie2: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    server.getData('', '/count/userTypeSize', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        that.setData({
          member_infor: res.data
        })
        setTimeout(function () {
          chart2.setOption(initChart2(res.data.useCardSize, res.data.wxnoCardSize, res.data.blocksize));
        }, 500)
      }
    })
  },

  // 获取统计信息
  getStatisInfor: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    server.getData('', '/count/nowDay', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        res.data.sumerMoenyDeal = Number(res.data.sumerMoeny / 100).toFixed(2)
        res.data.sumerAllMoenyDeal = Number(res.data.sumerAllMoeny / 100).toFixed(2)
        res.data.saleMoneyDeal = Number(res.data.saleMoney / 100).toFixed(2)
        res.data.payAllMoneyDeal = Number(res.data.payAllMoney / 100).toFixed(2)
        res.data.sumerAllVolDeal = Number(res.data.sumerAllVol / 100).toFixed(2)
        res.data.sumerDayVolDeal = Number(res.data.sumerDayVol / 100).toFixed(2)
        res.data.coinSumDeal = Number(res.data.coinSum / 100).toFixed(2)
        res.data.coinCountSumDeal = Number(res.data.coinCountSum / 100).toFixed(2)
        res.data.codeSumDeal = Number(res.data.codeSum / 100).toFixed(2)
        res.data.codeCountSumDeal = Number(res.data.codeCountSum / 100).toFixed(2)
        res.data.cardSumDeal = Number(res.data.cardSum / 100).toFixed(2)
        res.data.cardCountSumDeal = Number(res.data.cardCountSum / 100).toFixed(2)
        that.setData({
          statis_infor: res.data
        })
      }
    })
  },

  // 获取合伙人、物业公司数据
  getParPro: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    server.getData('', '/count/myProfitByRole', function (res) {
      console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (that.data.agent_status == 2) {
          res.data.dayMoneyDeal = (res.data.dayMoney / 100).toFixed(2)
          res.data.monthMoneyDeal = (res.data.monthMoney / 100).toFixed(2)
          res.data.normDeal = (res.data.norm / 100).toFixed(2)
          res.data.countMoneyDeal = (res.data.countMoney / 100).toFixed(2)
          res.data.noMoneyDeal = (res.data.noMoney / 100).toFixed(2)
          wx.setStorageSync('normDeal', res.data.norm)
          // res.data.remNormDeal = (res.data.remNorm / 100).toFixed(2)
        } else if (that.data.agent_status == 3) {
          res.data.countMoneyDeal = (res.data.countMoney / 100).toFixed(2)
          res.data.dayMoneyDeal = (res.data.dayMoney / 100).toFixed(2)
          res.data.monthMoneyDeal = (res.data.monthMoney / 100).toFixed(2)
          res.data.yearMoneyDeal = (res.data.yearMoney / 100).toFixed(2)
          res.data.noMoneyDeal = (res.data.noMoney / 100).toFixed(2)
        }
        that.setData({
          parpro_infor: res.data
        })
      }
    })
  },

  // 获取设备列表
  getEquipList: function () {
    var that = this;
    server.getData('', '/devices/findListByRole', function (res) {
      // console.log(res)
      if (res.code == 200) {
        if (res.data.length != 0) {
          that.data.equip_arr_show.push('全部设备')
          that.data.equip_arr.push({ deviceId: '', deviceName: '全部设备' })
          for (var i = 0; i < res.data.length; i++) {
            that.data.equip_arr_show.push(res.data[i].deviceName)
            that.data.equip_arr.push(res.data[i])
          }
          that.setData({
            equip_arr_show: that.data.equip_arr_show,
            equip_arr: that.data.equip_arr
          })
        } else {
          that.data.equip_arr_show.push('全部设备')
          that.data.equip_arr.push({ deviceId: '', deviceName: '全部设备' })
          that.setData({
            equip_arr_show: that.data.equip_arr_show,
            equip_arr: that.data.equip_arr
          })
        }
      }
    })
  },

  // 获取充值记录列表
  getRechargeRecord: function (deviceId, time, page, limit) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      deviceId: deviceId,
      time: time,
      page: page,
      limit: limit
    }
    server.postData(sendData, '/count/myPayLogList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].moneyDeal = (res.data[i].money / 100).toFixed(2)
          }
          var recharge_list = that.data.recharge_list.concat(res.data);
          that.setData({
            recharge_list: recharge_list,
            recharge_list_status: true,
          })
          var count = res.count;
          var total_page = count / 10 < 1 ? 0 : count / 10;
          if (count % 10 == 0) {
            that.data.total_page = total_page;
          } else {
            that.data.total_page = parseInt(total_page) + 1;
          }
        } else {
          that.setData({
            recharge_list: [],
            recharge_list_status: false
          })
        }
      }
    })
  },

  // 页面滚动到底部时
  toLower: function () {
    var that = this;
    if (that.data.share_cate == '1') {
      var current_page = that.data.current_page + 1;
      that.setData({
        current_page: current_page
      })
      if (current_page <= that.data.total_page) {
        var tiem_cate = that.data.time_index == 0 ? 'day' : 'month'
        // 获取充值记录列表
        that.getRechargeRecord(that.data.equip_arr[that.data.equip_index].deviceId, tiem_cate, current_page, '10')
      }
    } else if (that.data.share_cate == '2') {
      var rent_current_page = that.data.rent_current_page + 1;
      that.setData({
        rent_current_page: rent_current_page
      })
      if (rent_current_page <= that.data.rent_total_page) {
        // 获取设备租金列表
        getEquipRent(rent_current_page, '10')
      }
    }
  },

  // 监听时间类别
  bindTimeChange: function (e) {
    var that = this;
    that.setData({
      time_index: e.detail.value
    })
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.recharge_list = [];
    var tiem_cate = that.data.time_index == 0 ? 'day' : 'month'
    // 获取充值记录列表
    that.getRechargeRecord(that.data.equip_arr[that.data.equip_index].deviceId, tiem_cate, 1, '10')
  },

  // 监听设备选择
  bindEquipChange: function (e) {
    var that = this;
    that.setData({
      equip_index: e.detail.value
    })
    that.data.current_page = 1;
    that.data.total_page = '';
    that.data.recharge_list = [];
    var tiem_cate = that.data.time_index == 0 ? 'day' : 'month'
    // 获取充值记录列表
    that.getRechargeRecord(that.data.equip_arr[that.data.equip_index].deviceId, tiem_cate, 1, '10')
  },

  // 获取合伙人、物业公司统计情况
  getProStatis: function () {
    var that = this;
    server.getData('', '/count/profitByPro', function (res) {
      // console.log(res)
      if (res.code == 200) {
        res.data.countmoneyDeal = (res.data.countmoney / 100).toFixed(2)
        res.data.moneyDeal = (res.data.money / 100).toFixed(2)
        res.data.nomoneyDeal = (res.data.nomoney / 100).toFixed(2)
        that.setData({
          pro_statis: res.data
        })
      }
    })
  },

  // 获取设备租金列表
  getEquipRent: function (page, limit) {
    var that = this;
    var sendData = {
      page: page,
      limit: limit
    }
    server.postData(sendData, '/count/profitByProList', function (res) {
      console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        if (res.data.length != 0) {
          for (var i = 0; i < res.data.length; i++) {
            res.data[i].addressMoneyDeal = (res.data[i].addressMoney / 100).toFixed(2)
            res.data[i].rentDeal = (res.data[i].rent / 100).toFixed(2)
          }
          var equip_rent = that.data.equip_rent.concat(res.data);
          that.setData({
            equip_rent: equip_rent,
            equip_rent_status: true,
          })
          var count = res.count;
          var rent_total_page = count / 10 < 1 ? 0 : count / 10;
          if (count % 10 == 0) {
            that.data.rent_total_page = rent_total_page;
          } else {
            that.data.rent_total_page = parseInt(rent_total_page) + 1;
          }
        } else {
          that.setData({
            equip_rent: [],
            equip_rent_status: false
          })
        }
      }
    })
  },

  // 获取促销员开卡/充值记录
  getOpenRecharge: function (page, limit) {
    var that = this;
    var sendData = {
      page: page,
      limit: limit
    }
    server.postData(sendData, '/paylogs/findList', function (res) {
      console.log(res)
    })
  },

  // 点击底部导航
  skipPage: function (e) {
    var that = this;
    if (e.currentTarget.dataset.url != '') {
      wx.reLaunch({
        url: e.currentTarget.dataset.url,
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.judge_page_status) {
      if (that.data.agent_status == 1) {
        // 获取统计信息
        that.getStatisInfor()
      } else if (that.data.agent_status == 2) {
        // 促销员
        // 获取合伙人、物业公司数据
        that.getParPro()
        // // 获取促销员开卡/充值记录
        // that.getOpenRecharge(1, '10')
      }
    }
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this;
    that.data.judge_page_status = true
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})