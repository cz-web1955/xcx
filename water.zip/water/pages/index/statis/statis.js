// pages/index/statis/statis.js
import * as echarts from '../../../ec-canvas/echarts';
var app = getApp();
// 引入request.js
var server = require('../../../utils/request.js')
// 引入util.js
var util = require('../../../utils/util.js')

var chart1;
var chart2;
function getlineOption1(dateArr, sumArr, interval) {
  return {
    color: ["#67cc9e"],
    grid: {
      left: '5%',
      right: '12%',
      bottom: 20,
      top: '12%',
      containLabel: true
    },
    tooltip: {
      show: true,
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
      },
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      axisLabel: {
        interval: interval,
        rotate: 60,
        textStyle: {
          fontSize: 10
        }
      },
      data: dateArr,
    },
    yAxis: {
      x: 'center',
      type: 'value',
      splitLine: {
        lineStyle: {
          type: 'dashed'
        }
      }
    },
    series: [{
      type: 'line',
      data: sumArr
    }]
  }
}

function getlineOption2(dateArr, sumArr, interval) {
  return {
    color: ["#67cc9e"],
    grid: {
      left: '5%',
      right: '12%',
      bottom: 20,
      top: '12%',
      containLabel: true
    },
    tooltip: {
      show: true,
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
      },
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      axisLabel: {
        interval: interval,
        rotate: 60,
        textStyle: {
          fontSize: 10
        }
      },
      data: dateArr,
    },
    yAxis: {
      x: 'center',
      type: 'value',
      splitLine: {
        lineStyle: {
          type: 'dashed'
        }
      }
    },
    series: [{
      type: 'line',
      data: sumArr
    }]
  }
}

Page({

  /**
   * 页面的初始数据
   */
  data: {
    ecLine1: {
      onInit: function (canvas, width, height) {
        chart1 = echarts.init(canvas, null, { width: width, height: height });
        canvas.setChart(chart1);
        chart1.setOption(getlineOption1([], [], 0));
        return chart1;
      }
    },
    ecLine2: {
      onInit: function (canvas, width, height) {
        chart2 = echarts.init(canvas, null, { width: width, height: height });
        canvas.setChart(chart2);
        chart2.setOption(getlineOption2([], [], 0));
        return chart2;
      }
    },
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '统计', backStatus: false },
    top_height: '',
    window_height: app.globalData.windowHeight,
    area_list_show: [],
    area_list: [],
    area_index: 0,
    equip_list_show: [],
    equip_list: [],
    equip_index: 0,
    date_list: [
      { name: '本周', params: 'weeks', inter: 0 },
      { name: '本月', params: 'months', inter: 7 },
      { name: '本年', params: 'years', inter: 0 }
    ],
    recharge_index: 0,
    consume_index: 0,
    statis_infor: '',
    loading_layer_status: 'hidden',
    bottom_nav: [
      { title: '首页', iconUrl: 'https://api.010ozner.com/image/1.png', selected: false, pathUrl: '/pages/index/home/home' },
      { title: '统计', iconUrl: 'https://api.010ozner.com/image/22.png', selected: true, pathUrl: '' },
      { title: '我的', iconUrl: 'https://api.010ozner.com/image/3.png', selected: false, pathUrl: '/pages/index/mine/mine' }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // 获取区域列表
    that.getArea()
    // 获取设备列表
    that.getEquip()
    // 获取统计信息
    that.getStatisInfor()
    // 获取充值金额曲线数据
    that.getRechangeMoney('', '', 'weeks', 0)
    // 获取消费曲线数据
    that.getConsume('weeks', 0)
  },

  // 获取区域列表
  getArea: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      page: 1,
      limit: '10000'
    }
    server.postData(sendData, '/areas/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        that.data.area_list_show.push('全部区域')
        for (var i = 0; i < res.data.length; i++) {
          that.data.area_list_show.push(res.data[i].name)
        }
        that.data.area_list = res.data
        that.data.area_list.unshift({ id: '', name: '全部区域' })
        that.setData({
          area_list: that.data.area_list,
          area_list_show: that.data.area_list_show
        })
      }
    })
  },

  // 监听区域选择
  bindAreaChange: function (e) {
    var that = this;
    that.setData({
      area_index: Number(e.detail.value)
    })
    // 获取充值金额曲线数据
    that.getRechangeMoney(that.data.equip_list[that.data.equip_index].deviceId, that.data.area_list[Number(e.detail.value)].id, that.data.date_list[that.data.recharge_index].params, that.data.date_list[that.data.recharge_index].inter)
  },

  // 获取设备列表
  getEquip: function () {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      page: 1,
      limit: '100000',
    }
    server.postData(sendData, '/devices/findList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        that.data.equip_list_show.push('全部设备')
        for (var i = 0; i < res.data.length; i++) {
          that.data.equip_list_show.push(res.data[i].deviceName)
        }
        that.data.equip_list = res.data;
        that.data.equip_list.unshift({ id: '', deviceId: '', deviceName: '全部设备' })
        that.setData({
          equip_list_show: that.data.equip_list_show,
          equip_list: that.data.equip_list
        })
      }
    })
  },

  // 监听设备选择
  bindEquipChange: function (e) {
    var that = this;
    that.setData({
      equip_index: e.detail.value
    })
    // 获取充值金额曲线数据
    that.getRechangeMoney(that.data.equip_list[Number(e.detail.value)].deviceId, that.data.area_list[that.data.area_index].id, that.data.date_list[that.data.recharge_index].params, that.data.date_list[that.data.recharge_index].inter)
  },

  // 获取统计信息
  getStatisInfor: function () {
    var that = this;
    server.getData('', '/count/nowDay', function (res) {
      // console.log(res)
      if (res.code == 200) {
        res.data.saleMoneyDeal = (res.data.saleMoney / 100).toFixed(2)
        res.data.saleMonthMoneyDeal = (res.data.saleMonthMoney / 100).toFixed(2)
        res.data.allSumerMoenyDeal = (res.data.allSumerMoeny / 100).toFixed(2)
        res.data.noSumerMoenyDeal = (res.data.noSumerMoeny / 100).toFixed(2)
        that.setData({
          statis_infor: res.data
        })
      }
    })
  },

  // 获取充值金额曲线数据
  getRechangeMoney: function (deviceId, areaId, dayType, interval) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      deviceId: deviceId,
      areaId: areaId,
      dayType: dayType,
      payType: '',
    }
    server.postData(sendData, '/count/inoutCountMoeny', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        var date_arr = [];
        var sum_arr = [];
        for (var i = 0; i < res.data.length; i++) {
          date_arr.push(res.data[i].date)
          sum_arr.push(res.data[i].sum / 100)
        }
        chart1.setOption(getlineOption1(date_arr, sum_arr, interval));
      }
    })
  },

  // 获取消费曲线数据
  getConsume: function (dayType, interval) {
    var that = this;
    that.setData({
      loading_layer_status: 'show'
    })
    var sendData = {
      dayType: dayType,
      payType: '',
    }
    server.postData(sendData, '/count/countConsumerList', function (res) {
      // console.log(res)
      that.setData({
        loading_layer_status: 'hidden'
      })
      if (res.code == 200) {
        var date_arr = [];
        var sum_arr = [];
        for (var i = 0; i < res.data.length; i++) {
          date_arr.push(res.data[i].date)
          sum_arr.push(res.data[i].sum / 100)
        }
        chart2.setOption(getlineOption2(date_arr, sum_arr, interval));
      }
    })
  },

  // 点击充值额日期切换
  rechargeDateTab: function (e) {
    var that = this;
    that.setData({
      recharge_index: e.currentTarget.dataset.index
    })
    // 获取充值金额曲线数据
    that.getRechangeMoney(that.data.equip_list[that.data.equip_index].deviceId, that.data.area_list[that.data.area_index].id, e.currentTarget.dataset.params, Number(e.currentTarget.dataset.inter))
  },

  // 点击消费额日期切换
  consumeDateTab: function (e) {
    var that = this;
    that.setData({
      consume_index: e.currentTarget.dataset.index
    })
    // 获取消费曲线数据
    that.getConsume(e.currentTarget.dataset.params, Number(e.currentTarget.dataset.inter))
  },

  // 点击底部导航
  skipPage: function (e) {
    var that = this;
    if (e.currentTarget.dataset.url != '') {
      wx.reLaunch({
        url: e.currentTarget.dataset.url,
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})