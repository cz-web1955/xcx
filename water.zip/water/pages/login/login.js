// pages/login/login.js
var app = getApp();
// 引入request.js
var server = require('../../utils/request.js')
// 引入util.js
var util = require('../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    window_height: app.globalData.windowHeight,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  // 点击登录
  loginSubmit: function (e) {
    var that = this;
    var phone_reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/; // 验证手机号的正则表达式
    if (e.detail.value.phone == '') {
      wx.showToast({
        title: '请输入手机号！',
        icon: 'none',
        duration: 2000,
      })
    } else if (!phone_reg.test(e.detail.value.phone)) {
      wx.showToast({
        title: '请输入正确的手机号！',
        icon: 'none',
        duration: 2000,
      })
    } else if (e.detail.value.pass == '') {
      wx.showToast({
        title: '请输入密码！',
        icon: 'none',
        duration: 2000
      })
    } else {
      var sendData = {
        username: e.detail.value.phone,
        password: e.detail.value.pass,
        // openId: wx.getStorageSync('openId'),
        // sellerId: wx.getStorageSync('sellerId')
      }
      server.postLData(sendData, '/login', function (res) {
        // console.log(res)
        if (res.token) {
          wx.showToast({
            title: '登录成功！',
            icon: 'none',
          })
          wx.setStorageSync('token', res.token)
          wx.setStorageSync('pwd', e.detail.value.pass)
          wx.setStorageSync('username', e.detail.value.phone)
          setTimeout(function () {
            wx.reLaunch({
              url: '/pages/index/home/home',
            })
          }, 1500)
        } else {
          if (res.code == '401') {
            wx.showToast({
              title: res.message,
              icon: 'none'
            })
          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})