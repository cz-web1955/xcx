// pages/login/forgetPass/forgetPass.js
var app = getApp();
// 引入request.js
var server = require('../../../utils/request.js')
// 引入util.js
var util = require('../../../utils/util.js')
var code_interval = null; // 定义验证码倒计时

Page({

  /**
   * 页面的初始数据
   */
  data: {
    top_nav: { statusBarHeight: app.globalData.statusBarHeight, title: '忘记密码', backStatus: true },
    top_height: '',
    window_height: app.globalData.windowHeight,

    forpwd_phone_num: '',
    time_flag: '点击获取',
    current_time: 60,
    code_button_flag: false,
    security_code: '',
  },

  // 点击返回按钮
  backUp: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  // 获取手机号的值
  getForpwdPhoneNum: function (e) {
    var that = this;
    that.setData({
      forpwd_phone_num: e.detail.value,
    })
  },

  // 获取验证码
  getSecurityCode: function () {
    var that = this;
    var phone_reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/; // 验证手机号的正则表达式
    // 判断手机号
    if (that.data.forpwd_phone_num == '') {
      wx.showToast({
        title: '请输入手机号！',
        icon: 'none',
        duration: 1500,
      })
    } else if (!phone_reg.test(that.data.forpwd_phone_num)) {
      wx.showToast({
        title: '请输入正确的手机号！',
        icon: 'none',
        duration: 1500,
      })
    } else {

      var current_time = that.data.current_time;
      code_interval = setInterval(function () {
        current_time--;
        that.setData({
          time_flag: current_time + 's',
          code_button_flag: true,
        });
        if (current_time <= 0) {
          clearInterval(code_interval);
          that.setData({
            time_flag: '重新获取',
            code_button_flag: false,
          })
        }
      }, 1000)


      // server.getData('', app.globalData.sendUrl + '/users/getInit/' + that.data.openId, function (res) {
      //   // console.log(res)
      //   if (res.Code == 500) {
      //     // 用户存在
      //     var current_time = that.data.current_time;
      //     code_interval = setInterval(function () {
      //       current_time--;
      //       that.setData({
      //         time_flag: current_time + 's',
      //         code_button_flag: true,
      //       });
      //       if (current_time <= 0) {
      //         clearInterval(code_interval);
      //         that.setData({
      //           time_flag: '重新获取',
      //           code_button_flag: false,
      //         })
      //       }
      //     }, 1000)

      //     var sendData = {
      //       phone: that.data.forpwd_phone_num,
      //     }
      //     sendData = JSON.stringify(sendData)
      //     server.postData(sendData, app.globalData.sendUrl + '/users/sendMsg', function (res) {
      //       // console.log(res)
      //       if (res.Code == 200) {
      //         that.setData({
      //           security_code: res.Message
      //         })
      //       }
      //     })
      //   } else if (res.Code == 200) {
      //     // 用户不存在
      //     wx.showModal({
      //       title: '提示',
      //       content: '用户不存在，是否注册！',
      //       success(res) {
      //         if (res.confirm) {
      //           wx.navigateTo({
      //             url: '/pages/login/register/register',
      //           })
      //         }
      //       }
      //     })
      //   }
      // })
    }
  },

  // 点击下一步按钮
  forpassSubmit: function (e) {
    // console.log(e)
    var that = this;
    wx.navigateTo({
      url: '/pages/login/forgetPass/forgetNext/forgetNext?phone=' + e.detail.value.phoneInput,
    })
    // var phone_reg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/; // 验证手机号的正则表达式
    // if (e.detail.value.phoneInput == '') {
    //   wx.showToast({
    //     title: '请输入手机号！',
    //     icon: 'none',
    //     duration: 1500,
    //   })
    // } else if (!phone_reg.test(e.detail.value.phoneInput)) {
    //   wx.showToast({
    //     title: '请输入正确的手机号！',
    //     icon: 'none',
    //     duration: 1500,
    //   })
    // } else if (e.detail.value.codeInput == '') {
    //   wx.showToast({
    //     title: '请输入验证码！',
    //     icon: 'none',
    //     duration: 1500,
    //   })
    // } else if (e.detail.value.codeInput != that.data.security_code) {
    //   wx.showToast({
    //     title: '请输入正确的验证码！',
    //     icon: 'none',
    //     duration: 1500,
    //   })
    // } else {
    //   wx.navigateTo({
    //     url: '/pages/login/forPass/forPassNext/forPassNext?phone=' + e.detail.value.phoneInput,
    //   })
    // }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 获取scroll-view的上边界坐标
    util.getRect('scroll-area', function (res) {
      that.setData({
        top_height: res
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})