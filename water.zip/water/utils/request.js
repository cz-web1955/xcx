
// var url = 'http://192.168.0.115:8777'
var url = 'https://api.010ozner.com'

function getData(sendData, sendUrl, callBack) {
  wx.request({
    url: url + sendUrl,
    data: sendData,
    header: {
      token: wx.getStorageSync('token'),
    },
    method: 'GET',
    success: function (res) {
      // console.log(res)
      if (res.data.code == '401') {
        wx.clearStorageSync('token')
        wx.clearStorageSync('user')
        wx.reLaunch({
          url: '/pages/login/login',
        })
      } else {
        callBack(res.data);  // 成功后回调方法
      }
    },
    fail: function (res) {
      console.log(res)
      if (res.errMsg == 'request:fail timeout') {
        wx.showToast({
          title: '请求超时，即将返回首页！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '/pages/index/home/home',
          })
        }, 1500)
      }
    },
    complete: function (res) {
      // console.log(res)
      if (res.errMsg == 'request:fail timeout') {
        wx.showToast({
          title: '请求超时，即将返回首页！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '/pages/index/home/home',
          })
        }, 1500)
      }
    }
  })
}

function postData(sendData, sendUrl, callBack) {
  wx.request({
    url: url + sendUrl,
    data: sendData,
    header: {
      token: wx.getStorageSync('token'),
    },
    method: 'POST',
    success: function (res) {
      // console.log(res)
      if (res.data.code == '401') {
        wx.clearStorageSync('token')
        wx.clearStorageSync('user')
        wx.reLaunch({
          url: '/pages/login/login',
        })
      } else {
        callBack(res.data);  // 成功后回调方法
      }
    },
    fail: function (res) {
      console.log(res)
      if (res.errMsg == 'request:fail timeout') {
        wx.showToast({
          title: '请求超时，即将返回首页！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '/pages/index/home/home',
          })
        }, 1500)
      }
    },
    complete: function (res) {
      // console.log(res)
      if (res.errMsg == 'request:fail timeout') {
        wx.showToast({
          title: '请求超时，即将返回首页！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '/pages/index/home/home',
          })
        }, 1500)
      }
    }
  })
}

function postFData(sendData, sendUrl, callBack) {
  wx.request({
    url: url + sendUrl,
    data: sendData,
    header: {
      token: wx.getStorageSync('token'),
      'content-type': 'application/x-www-form-urlencoded'
    },
    method: 'POST',
    success: function (res) {
      // console.log(res)
      if (res.data.code == '401') {
        wx.clearStorageSync('token')
        wx.clearStorageSync('user')
        wx.reLaunch({
          url: '/pages/login/login',
        })
      } else {
        callBack(res.data);  // 成功后回调方法
      }
    },
    fail: function (res) {
      if (res.errMsg == 'request:fail timeout') {
        wx.showToast({
          title: '请求超时，即将返回首页！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '/pages/index/home/home',
          })
        }, 1500)
      }
    },
    complete: function (res) {
      // console.log(res)
      if (res.errMsg == 'request:fail timeout') {
        wx.showToast({
          title: '请求超时，即将返回首页！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '/pages/index/home/home',
          })
        }, 1500)
      }
    }
  })
}

function postLData(sendData, sendUrl, callBack) {
  wx.request({
    url: url + sendUrl,
    data: sendData,
    header: {
      'content-type': 'application/x-www-form-urlencoded'
    },
    method: 'POST',
    success: function (res) {
      // console.log(res)
      callBack(res.data);  // 成功后回调方法
    },
    fail: function (res) {
      console.log(res)
      if (res.errMsg == 'request:fail timeout') {
        wx.showToast({
          title: '请求超时，即将返回首页！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '/pages/index/home/home',
          })
        }, 1500)
      }
    },
    complete: function (res) {
      // console.log(res)
      if (res.errMsg == 'request:fail timeout') {
        wx.showToast({
          title: '请求超时，即将返回首页！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '/pages/index/home/home',
          })
        }, 1500)
      }
    }
  })
}

function postPData(sendData, sendUrl, callBack) {
  wx.request({
    url: url + sendUrl,
    data: sendData,
    header: {
      token: wx.getStorageSync('token'),
      'content-type': 'application/x-www-form-urlencoded'
    },
    method: 'PUT',
    success: function (res) {
      // console.log(res)
      if (res.data.code == '401') {
        wx.clearStorageSync('token')
        wx.clearStorageSync('user')
        wx.reLaunch({
          url: '/pages/login/login',
        })
      } else {
        callBack(res.data);  // 成功后回调方法
      }
    },
    fail: function (res) {
      console.log(res)
      if (res.errMsg == 'request:fail timeout') {
        wx.showToast({
          title: '请求超时，即将返回首页！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '/pages/index/home/home',
          })
        }, 1500)
      }
    },
    complete: function (res) {
      // console.log(res)
      if (res.errMsg == 'request:fail timeout') {
        wx.showToast({
          title: '请求超时，即将返回首页！',
          icon: 'none'
        })
        setTimeout(function () {
          wx.reLaunch({
            url: '/pages/index/home/home',
          })
        }, 1500)
      }
    }
  })
}

module.exports = {
  getData: getData,
  postData: postData,
  postFData: postFData,
  postLData: postLData,
  postPData: postPData
}